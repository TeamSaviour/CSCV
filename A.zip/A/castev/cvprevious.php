
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Caste Certificate And Validity System</title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
	<link rel="stylesheet" href="../assets/css/ready.css">
	<link rel="stylesheet" href="../assets/css/demo.css">
        <script src="../assets/js/core/jquery.3.2.1.min.js"></script>

        <style>
         
		.form-group.required .control-label:before {
  content:"*";
  color:red;
}
  span{
     color: red;
  }
 
            </style>
        <link rel="stylesheet" href="https://unpkg.com/bootstrap-material-design@4.1.1/dist/css/bootstrap-material-design.min.css" integrity="sha384-wXznGJNEXNG1NFsbm0ugrLFMQPWswR3lds2VeinahP8N0zJw9VWSopbjv2x7WCvX" crossorigin="anonymous">
</head>
<body>
	<div class="wrapper">
		<div class="main-header">
			<div class="logo-header">
				
				<a href="index.html" class="logo">
				CCVS
				</a>
				<button class="navbar-toggler sidenav-toggler ml-auto bmd-btn-fab dropdown-toggle" type="button" data-toggle="collapse" data-target="collapse" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				
			</div>
			
			</div>
			<div class="sidebar">
				<div class="scrollbar-inner sidebar-wrapper">
			
					
					<ul class="nav">
            <li class="nav-item active">
              <a href="#">
                <i class="la la-home"></i>
                <p>Home</p>
                <span class="badge badge-count"></span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#">
                <i class="la la-edit"></i>
                <p>Apply</p>
                <span class="badge badge-count"></span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#">
                <i class="la la-download"></i>
                <p>Downloads</p>
                <span class="badge badge-count"></span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#">
                <i class="la la-upload"></i>
                <p>Upload Documents</p>
                <span class="badge badge-count"></span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#">
                <i class="la la-user"></i>
                <p>Edit Profile</p>
                <span class="badge badge-success"></span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#">
                <i class="la la-files-o"></i>
                <p>Verify Certificate</p>
                <span class="badge badge-danger"></span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#">
                <i class="la la-sign-out"></i>
                <p>Logout</p>
              </a>
            </li>
          </ul>
				</div>
			</div>
			<div class="main-panel">
				<div class="content">
                                    <div class="container">
                                    <form>
	<div class="container-fluid col-xl-12">
		<div class="card col-md-12">
      <p class="bg-info text-white card-header col-xl-12 ">Caste Certificate Validity Details of Applicant's Blood Relation(s)</p> 
    <div class="card col-xl-12">
        <p>
        <div class="form-group col-xl-12 row">
        	
        	<label class="col-md-4">Did any verification take place for any relative earlier?</label>
        	
            <label class="radio-inline col-md-4"><input type="radio" name="optradio" required><span class="form-radio-sign">Yes</span></label>
            <label class="radio-inline col-md-4"><input type="radio" name="optradio">No</label>
        </div> 
        </p>
    </div>   
    

        <!-- Previous Application Details Of Applicant -->
        <p>

        <p class="bg-info text-white card-header col-md-12" id="previous">Previous Application Details Of Applicant</p>
         <div class="card col-md-12">
        <p>
        <div class="form-group col-md-12 row">
        	
        	<label class="col-md-4">If applicant has applied for caste validity certificate before any commitee in Maharashtra</label> 
        	
                <label class="radio-inline col-md-4"><input type="radio" name="optradio" required><span class="custom-radio-sign">Yes</span></label>
                <label class="radio-inline col-md-4"><input type="radio" name="optradio"><span class="custom-radio-sign">No</span></label>
        </div> 
        </p>  
     

        
        <div class="form-group">
   		       	<label for="commitee" class="col-md-12 col-form-label control-label">Which commitee
   			   		<select class="custom-select col-md-8" id="commitee">
   		                <option>--select Scrutiny Commitee--</option>		
       	                <option>Education</option>
       	                <option>Business</option>
                        <option>Service</option>
                        <option>other</option>
       	            </select>
   		        </label>
   		</div>  

        

         <div class="form-group">
   		       	<label for="category" class="col-md-12 col-form-label control-label">Category Applied
   			   		<select class="form-control col-md-8" id="category">
   		                <option>--select category--</option>		
       	               <option>Sheduled Caste</option>
       	            <option>Scheduled Caste Converted To Buddism</option>
                    <option>Vimukta Jati(A)</option>
                    <option>Nomadic Tribe(B)</option>
                    <option>Nomadic Tribe(C)</option>
                    <option>Nomadic Tribe(D)</option>
                    <option>Other Backward Class</option>
                    <option>Special Backward Class</option>
                    <option>Educationally and Socially Backward Category</option>
                    <option>Special Backward Category(A)</option>
       	            </select>
   		        </label>
   		</div>  



        <div class="form-group">
   		       	<label for="caste" class="col-md-12 col-form-label control-label">Caste Applied
   			   		<select class="form-control col-md-8" id="caste">
   		                <option>--select caste--</option>		
       	                <option>Education</option>
       	                <option>Business</option>
                        <option>Service</option>
                        <option>other</option>
       	            </select>
   		        </label>
   		</div>  

        

        <div class="form-group">
   		       	<label for="subcaste" class="col-md-12 col-form-label control-label">Sub cast
   			   		<select class="form-control col-md-8" id="subcaste">
   		                <option>--select subcaste--</option>		
       	                <option>Education</option>
       	                <option>Business</option>
                        <option>Service</option>
                        <option>other</option>
       	            </select>
   		        </label>
   		</div>  

         <div class="form-group row">
            <div class="form group required col-md-6">
   			    <label for="date" class="col-md-12 col-form-label control-label">Date of Application
 					<input type="text" class="form-control" id="date" placeholder="Date">
                </label>
   		    </div>
   	    
           

        
   		    <div class="col-md-6">
   		        <label for="dicision" class="col-md-12 col-form-label control-label">Commitee's Decision
   			   		<select class="form-control" id="dicision">
   		                <option>--select Commitee Decision--</option>		
       	                <option>Ahmednagar</option>
       	                <option>Akola</option>
                        <option>Amravati</option>
                        <option>Aurangabad</option>
       	            </select>
   		        </label>
   		    </div>
        </div>

        

        <div class="form-group">
   		       	<label for="scrutiny" class="col-md-12 col-form-label control-label">Purpose of Scrutiny
   			   		<select class="form-control col-md-8" id="scrutiny">
   		                <option>--select purpose of Scrutiny--</option>		
       	                <option>Education</option>
       	                <option>Business</option>
                        <option>Service</option>
                        <option>other</option>
       	            </select>
   		        </label>
   		</div> 
   		</div>
        </p>
    <!-- Documents -->
    <p>
            
                <p class="bg-info text-white card-header col-md-12" id="previous">Documents</p>
         <div class="card col-md-12">
    <p>
        <div class="form-check">
            <label class="form-check-label col-md-12">
               <input type="checkbox" class="form-check-input" value="">Other Documents
               <textarea class="form-control col-md-8" rows="2" id="documents"></textarea>
            </label>
        </div>
         </p>
        </div>
   
         <!-- Declaration -->
           <p>
        <div class="form-group col-sm-12">
                <h4>Declaration</h4>
        </div>
        </p>
   
    <div class="form-group">
        <textarea class="col-xl-12 form-control " rows="3" style="overflow-y:scroll;" id="area">
         -All details mentioned in application are true to best of my knowledge
         -Caste certificate number which I have mentioned in application is the 
          only one caste certificate I possessed via legal channels
         -I have never applied for caste validity certificate before 
        </textarea>
    </div>


    <div class="form-check">
            <label class="form-check-label col-md-12">
               <input type="checkbox" class="form-check-input" value="">I agree to all terms and conditions started in above declaration.
               
            </label>
    </div>
</p>
        

  

 <div class="buttonholder">
     <a href="fatheredu.php" class="previous btn btn-primary btn-raised">&laquo; Previous</a>
      
        <button type="submit" class="save btn btn-success btn-raised " >Submit</button>

       </div>
  </div>           
</div>
    </div>

</form>    
                                    </div>
					</div>
				</div>
				
			
	


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://unpkg.com/popper.js@1.12.6/dist/umd/popper.js" integrity="sha384-fA23ZRQ3G/J53mElWqVJEGJzU0sTs+SvzG8fXVWP+kJQ1lwFAOkcUOysnlKJC33U" crossorigin="anonymous"></script>
<script src="https://unpkg.com/bootstrap-material-design@4.1.1/dist/js/bootstrap-material-design.js" integrity="sha384-CauSuKpEqAFajSpkdjv3z9t8E7RlpJ1UP0lKM/+NdtSarroVKu069AlsRPKkFBz9" crossorigin="anonymous"></script>
<script src="../assets/js/core/jquery.3.2.1.min.js"></script>
<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>

<script src="../assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>
<script src="../assets/js/plugin/bootstrap-toggle/bootstrap-toggle.min.js"></script>
<script src="../assets/js/plugin/jquery-mapael/jquery.mapael.min.js"></script>
<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
<script src="../assets/js/ready.min.js"></script>
<script src="../assets/js/demo.js"></script>
</body>
</html>