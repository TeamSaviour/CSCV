<html>
    <head>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>

        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
        
    </head>
    <body>
        
        
        <?php
        
            $host="localhost";
            $username="root";
            $password="";
            $database="as";
            
            $conn= mysqli_connect($host, $username, $password, $database);
            
            if(!$conn)
            {
                 die("failed ".mysqli_connect_error() );    
                
            }
            echo "connected";
            
            //$sql="select * from appdetails NATURAL JOIN address NATURAL JOIN relationofbeneficiary NATURAL JOIN  beneficiarydetails ";
            //$sql="select * from appdetails where id='2'";
            $sql="select * from appdetails apd INNER JOIN address appAddr on apd.id=appAddr.id INNER JOIN relationofbeneficiary rob on appAddr.id=rob.id "
                    . "INNER JOIN  beneficiarydetails bd on rob.id=bd.id INNER JOIN beneficiaryfatherdetails bfd on bd.id=bfd.id "
                    . "INNER JOIN  bfaddressdetails bfaAddr on bfd.id=bfaAddr.id INNER JOIN  bcastecategorydetails bccd on bfaAddr.id=bccd.id "
                    . "INNER JOIN  beneficiaryotherdetails bod on bccd.id=bod.id INNER JOIN attachmenttobeattached atba on bod.id=atba.id  "
                    . "INNER JOIN  additionalinfo ai on atba.id=ai.id  INNER JOIN  otherdetails od on ai.id=od.id where apd.id=2";
            
            $result=mysqli_query($conn, $sql);
             
            if (mysqli_num_rows($result) > 0)
          {
    // output data of each row
             while($row = mysqli_fetch_assoc($result))
            
            {
       // echo  "<br>".$row["fullnameEnglish"];
    

        
        ?>
        
        
        
        

        <div class="container col-sm-8">
            <form method="post" action="createPDF1.php">
            <div class="card">
                <div class="card-body">
                
                    <div class="row col-sm-11" style="background-color: greenyellow;margin-left:5px;font-size: 20px"><strong>1.&nbsp; Applicants Details</strong> </div>   
                
                <br>
                <div class="row" style="margin-left:35px">
                    <label ><strong>Full Name :</strong></label>    
                    <div style="margin-left: 95px"><?php echo $row['fullnameEnglish'] ?></div>
                </div>
                
                <br>
                <div class="row" style="margin-left:35px">
                    <label ><strong>Father's Name :</strong> </label>    
                    <div style="margin-left: 65px"><?php echo $row['fathernameEnglish']; ?></div>
                </div>
                <br>
                <div class="row" style="margin-left:35px">
                    <label ><strong>Date Of Birth :</strong> </label>    
                    <div style="margin-left: 75px"><?php echo $row['dob']; ?></div>
                </div>
                <br>
                <div class="row" style="margin-left:35px">
                    <label ><strong>Age :</strong> </label>    
                    <div style="margin-left: 140px"><?php echo $row['age']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Mobile Number :</strong> </label>    
                    <div style="margin-left: 55px"><?php echo $row['amob']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Gender :</strong> </label>    
                    <div style="margin-left: 115px"><?php echo $row['Agender']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Email ID :</strong> </label>    
                    <div style="margin-left: 110px"><?php echo $row['aemail']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Occupation :</strong></label>    
                    <div style="margin-left: 85px"><?php echo $row['aoccupation']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Aadhar Number :</strong> </label>    
                    <div style="margin-left: 55px"><?php echo $row['aaadhar']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Applicant Nationality :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['anationality']; ?></div>
                </div>
                
                               
   <!---------------------------------------------------------------------------------------------------------------------------------------->          
                   
   <br>
                <br>
                <div class="row col-sm-8" style="background-color:yellow;margin-left:20px;font-size: 20px"><strong> Address Details</strong> </div>   

                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Address :</strong></label>    
                    <div style="margin-left: 50px"><?php echo $row['Address']; ?></div>
                </div >
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Building :</strong></label>    
                    <div style="margin-left: 50px"><?php echo $row['Building']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Section :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['Section']; ?></div>
                </div>
                
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Street :</strong></label>    
                    <div style="margin-left: 65px"><?php echo $row['Street']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Landmark :</strong></label>    
                    <div style="margin-left: 35px"><?php echo $row['Landmark']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>District :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['District']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Taluka :</strong></label>    
                    <div style="margin-left: 60px"><?php echo $row['Taluka']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Village :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['Village']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Pincode :</strong></label>    
                    <div style="margin-left: 45px"><?php echo $row['Pincode']; ?></div>
                </div>
                
        <!---------------------------------------------------------------------------------------------------------------------------------------->          
            
      <hr>
                <br>
                <div class="row col-sm-11" style="background-color: greenyellow;margin-left:5px;font-size: 20px"><strong>2. &nbsp;Relation Of Beneficiary With Applicant</strong></div>   
                <br>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Relation Of Beneficiary With Applicant :</strong></label>    
                    <div style="margin-left: 25px"><?php echo $row['relationOFBeneficiary']; ?></div>
                </div>
                
                     	
      <!---------------------------------------------------------------------------------------------------------------------------------------->          
                <hr>
                 <br>
                 <div class="row col-sm-11" style="background-color: greenyellow;margin-left:5px;font-size: 20px"><strong>3. &nbsp;Beneficiary Details</strong></div>   
                <br>
                
                <div class="row" style="margin-left:35px">
                    <label ><strong>Full Name :</strong></label>    
                    <div style="margin-left: 95px"><?php echo $row['fullnamEnglish']; ?></div>
                </div>
              
                <br>
                <div class="row" style="margin-left:35px">
                    <label ><strong>Date Of Birth :</strong></label>    
                    <div style="margin-left: 75px"><?php echo $row['dob']; ?></div>
                </div>
                <br>
              
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Mobile Number :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['mob']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Gender :</strong></label>    
                    <div style="margin-left: 115px"><?php echo $row['gender']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Email ID :</strong></label>    
                    <div style="margin-left: 110px"><?php echo $row['email']; ?></div>
                </div>
               
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Aadhar Number :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['adhar']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Applicant Nationality :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['applicantNationality']; ?></div>
                </div>
                
     <!---------------------------------------------------------------------------------------------------------------------------------------->          
     
                <br>
                <br>
                <div class="row col-sm-8" style="background-color: yellow;margin-left:20px;font-size: 20px"><strong>Other Details</strong></div>   
                <br>
               
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Name of the Post :</strong></label>    
                    <div style="margin-left: 60px"><?php echo $row['nameOfThePost']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Herediatary Occupation :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['herediataryOccupation']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Permanant Address (Yes/No) </strong></label>    
                    <div style="margin-left: 50px"><?php echo $row['permanantAddr']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>If migrated from one state to another state?(Yes/No) :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['ifMigrated']; ?></div>
                </div>          
                
    <!---------------------------------------------------------------------------------------------------------------------------------------->          
                  <hr>
                 <br>
                 <div class="row col-sm-11" style="background-color: greenyellow;margin-left:5px;font-size: 20px"><strong>3. &nbsp;Beneficiary Father Details</strong></div>   
                <br>
                
                <div class="row" style="margin-left:35px">
                    <label ><strong>Full Name :</strong></label>    
                    <div style="margin-left: 105px"><?php echo $row['fullnameE']; ?></div>
                </div>
                <br>
                <div class="row" style="margin-left:35px">
                    <label ><strong>Date Of Birth :</strong></label>    
                    <div style="margin-left: 85px"><?php echo $row['dob']; ?></div>
                </div>
               
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Mobile Number :</strong></label>    
                    <div style="margin-left: 65px"><?php echo $row['mob']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Gender :</strong></label>    
                    <div style="margin-left: 125px"><?php echo $row['gender']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Email ID :</strong></label>    
                    <div style="margin-left: 120px"><?php echo $row['email']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Occupation :</strong></label>    
                    <div style="margin-left: 95px"><?php echo $row['occupation']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Aadhar Number :</strong></label>    
                    <div style="margin-left: 65px"><?php echo $row['adhar']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Applicant Nationality :</strong></label>    
                    <div style="margin-left: 30px"><?php echo $row['applicantNationality']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Herediatary Occupation:</strong></label>    
                    <div style="margin-left: 15px"><?php echo $row['herediataryOccupation']; ?></div>
                </div>
                
    <!---------------------------------------------------------------------------------------------------------------------------------------->          
    <br>
                 <br>
                 <div class="row col-sm-8" style="background-color: yellow;margin-left:20px;font-size: 20px"><strong>Beneficiary Father Address Details</strong></div>   
                <br>
                
                <div class="row" style="margin-left:35px">
                    <label ><strong>Address :</strong></label>    
                    <div style="margin-left: 50px"><?php echo $row['Address']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Building :</strong></label>    
                    <div style="margin-left: 50px"><?php echo $row['Building']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Section :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['Section']; ?></div>
                </div>
               
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Street :</strong></label>    
                    <div style="margin-left: 65px"><?php echo $row['Street']; ?></div>
                </div>
                   <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Landmark :</strong></label>    
                    <div style="margin-left: 35px"><?php echo $row['Landmark']; ?></div>
                </div>
                <br>

                 <div class="row" style="margin-left:35px">
                     <label ><strong>District :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['District']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Taluka :</strong></label>    
                    <div style="margin-left: 60px"><?php echo $row['Taluka']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Village :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['Village']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Pincode :</strong></label>    
                    <div style="margin-left: 45px"><?php echo $row['Pincode']; ?></div>
                </div>
                
                
      <!---------------------------------------------------------------------------------------------------------------------------------------->          
    
       <hr>
                 <br>
                 <div class="row col-sm-11" style="background-color: greenyellow;margin-left:5px;font-size: 20px"><strong>4. &nbsp;Beneficiary Caste/Category Details</strong></div>   
                <br>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Caste :</strong></label>    
                    <div style="margin-left: 85px"><?php echo $row['caste']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Category :</strong></label>    
                    <div style="margin-left: 60px"><?php echo $row['category']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Religion :</strong></label>    
                    <div style="margin-left:65px"><?php echo $row['religion']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Sub Caste :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['subcaste']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Mother Tounge :</strong></label>    
                    <div style="margin-left: 15px"><?php echo $row['mother_tounge']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Dialect :</strong></label>    
                    <div style="margin-left: 80px"><?php echo $row['dialect']; ?></div>
                </div>
                
             
       <!---------------------------------------------------------------------------------------------------------------------------------------->          
     
       <hr>
                 <br>
                 <div class="row col-sm-11" style="background-color: greenyellow;margin-left:5px;font-size: 20px"><strong>5. &nbsp;Beneficiary Other Details</strong></div>   
                <br>
                
                  <div class="row" style="margin-left:35px">
                      <label ><strong>original Village/Town(Place)/tahsil/district of the person</strong></label>    
                 </div>
                
            
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>District :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['originaldistrict']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Taluka :</strong></label>    
                    <div style="margin-left: 25px"><?php echo $row['originaltaluka']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Village :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['originalvillage']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Name of the Village/Town,if a person is residing in the Village/Town other than his original Village /</strong></label>
                     <label><strong>Town (ordinary place of residence) :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['nameOfVillageORTown']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>District :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['Residingdistrict']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Taluka :</strong></label>    
                    <div style="margin-left: 25px"><?php echo $row['Residingtaluka']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Village :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['Residingvillage']; ?></div>
                </div>
                <br>
                  <div class="row" style="margin-left:35px">
                      <label ><strong>Year of leaving the original Village :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['yearOfLeaving']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:20px">
                     <label class="col-sm-12" ><strong>Reason for leaving the original Village ( i.e Education,employement etc.) :</strong></label>    
                    <div style="margin-left: 0px" class="col-sm-12"><?php echo $row['reasonForLeaving']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:20px">
                     <label class="col-sm-12"><strong>Reason for residing in the present Village ( i.e Education,employement etc.) :</strong></label>    
                    <div style="margin-left: 0px" class="col-sm-12"><?php echo $row['reasonForResiding']; ?></div>
                </div>
             
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Place Of Birth :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['birthPlace']; ?></div>
                </div>
                
                <br>
                 <div class="row" style="margin-left:20px">
                     <label class="col-sm-12"><strong>Name of the primary school and Full Address :</strong></label>    
                    <div style="margin-left: 0px" class="col-sm-12"><?php echo $row['nameOfPschool']; ?></div>
                </div>
                <br>
                <div class="row" style="margin-left:20px">
                    <label class="col-sm-12"><strong>Name of the secondary school and Full Address :</strong></label>    
                    <div style="margin-left: 0px" class="col-sm-12"><?php echo $row['nameOfSscool']; ?></div>
                </div>
                
                
      <!---------------------------------------------------------------------------------------------------------------------------------------->          
                  
       <hr>
                 <br>
                 <div class="row col-sm-11" style="background-color: greenyellow;margin-left:5px;font-size: 20px"><strong>6. &nbsp;Attachment to be Attached</strong></div>   
                <br>
                
                 
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Evidence in support of this Scheduled Caste Claim :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['evidence']; ?></div>
                </div>
                <br>
                
                 <div class="row" style="margin-left:35px">
                     <label><strong>Extract of the birth register in respect of application,his father or relatives:</strong></label>    
                    <div style="margin-left: 25px"><?php echo $row['eofbirthRegister']; ?></div>
                </div>
                <br>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Extract of the Primary School Admission Register of the applicant :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['eofprimaryShoolAdmission']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Primary School Leaving Certificate of the applicant or his father :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['pschoolLeaving']; ?></div>
                </div>
                <br>
                 <div class='row' style="margin-left:35px">
                     <label ><strong>Documentary evidence in regard to the Schedule Caste and ordinary place of residence prior to the </strong></label>
                     <label><strong>date of notification of such :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['documentaryEvidence']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label><strong>An extract of service record a (book) mentioning Scheduled Caste of the applicant's father or relatives </strong></label>
                     <label><strong> who are in Government or any other services if any :</strong></label>    
                     <div style="margin-left: 20px" ><?php echo $row['eofServiceRecords']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>True copy of Validity Certificate,if any of the other father or relatives which issued by the Scrutiny</strong></label>
                     <label><strong>Committee :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['trueCopyOfValidity']; ?></div>
                </div>
                
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Copy of Revenue record or village panchayat record,if any :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['copyOfRevenueRecord']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Other relevant documentary evidence,if any :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['otherRelevantDocuments']; ?></div>
                </div>

                
      
   <!---------------------------------------------------------------------------------------------------------------------------------------->          

       <hr>
                 <br>
                 <div class="row col-sm-11" style="background-color: greenyellow;margin-left:5px;font-size: 20px"><strong>7. &nbsp;Additional Information</strong></div>   
                <br>
                
                  <div class="row" style="margin-left:35px">
                      <label ><strong>Name of five villages where applicant's relatives reside :</strong></label>    
                    <div style="margin-left: -15px" class="row col-sm-12"><?php echo $row['nameOfVillages']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>GodNames <br> Scheduled Caste :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['godNamesSC']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label class="row col-sm-11"><strong>In case of a person converted to another religion,the names of the gods and goddesses worshiped by him prior to conversion :</strong></label>    
                    <div style="margin-left: -15px" class="col-sm-12"><?php echo $row['personConvertedToAnotherReligion']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>The applicant's father's/ grandfather's original village/town, tahsil and district :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['aFathersOriginalVillage']; ?></div>
                </div>
      
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>The evidence of the applicants original village/town, if any. :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['eOfOriginalVillages']; ?></div>
                </div>
                
                <br>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Whether the father or relatives obtained the Scheduled Caste :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['fatherOrRelativesObtainedSc']; ?></div>
                </div>
                <br>
                
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>The Affidavit to be attached here with Form-2 and Form-3 :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['affidavitToBeAttached']; ?></div>
                </div>
                
                <br>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Whether the applicant has applied to the Competent Authority in Maharastra State or Competent</strong></label>
                     <label><strong> Authority of other State previously for issuance of Scheduled Caste :</strong></label>    
                     <div style="margin-left: 20px"><?php echo $row['aAppliedToCompetentAuthority']; ?></div>
                </div>
                <br>
                <div class="row" style="margin-left:35px">
                    <label ><strong>Whether a Validity Certificate is granted to the father or any relatives of the applicant by the Scrutiny</strong></label>
                    <label><strong>Committee :</strong></label>
                    <div style="margin-left: 20px" ><?php echo $row['validityIsGranted']; ?></div> 
                                    
                </div>
                
     <!---------------------------------------------------------------------------------------------------------------------------------------->          
              
     <br>
                 <br>
                 <div class="row col-sm-8" style="background-color: yellow;margin-left:20px;font-size: 20px"><strong>Other Details</strong></div>   
                <br>
                
                 <div class="row" style="margin-left:20px">
                     <label class="col-sm-12"><strong>Reason :</strong></label>    
                    <div style="margin-left: 15px"  ><?php echo $row['reason']; ?></div>
                </div>
                <br>
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Do you need Affidavit ?</strong> </label>    
                    <div style="margin-left: 20px"><?php echo $row['doYouNeedAffidavit']; ?></div>
                </div>
      
      
                
                
                
                
                
             
                
                </div>
            </div>
            </form>
        </div>
  
            <?php
                            }
                   }
                   else 
                   {
                       echo "0 results";
                   }
                   
                   
                   
             ?>
   
                
        
    </body>
</html>
