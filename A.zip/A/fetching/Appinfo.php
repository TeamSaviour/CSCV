
<html>
    <head>
        
        <title>Applicant Information</title>
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
   

<script>
// Example starter JavaScript for disabling form submissions if there are invalid fields
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('addappinfo', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
</script>



    
<style>
   
   .radio  {
                margin-bottom: 10px;
                padding: 10px ;
            }
            
  .form-check-input{
                
                        width: 20px;
                        height: 20px;
                    }
                    
             .card {
                        background-color: white;
                        color:black
             }
                    
                  
                    
   
                    
                   
</style>

    </head>
    
    <body>
     <?php
                  require_once 'connection.php';
                  $sql="select * from appdetails where username='anand'";
                $result= mysqli_query($connection, $sql);
                                    while ($row=mysqli_fetch_array($result)){
                      
                  
                  ?>
        <div class="container col-sm-10">        
            <form class="needs-validation" novalidate method="POST"  id="apform" name="aform">    
                
          <!--*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*++*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*+*--> 
          <div class="" > <fieldset id="myfieldset">
                 <div class="card">                    
                    <div class="card-body">

                 
                        <div class="row" style="padding-left:10px;font-size:20px">
                            
                            <strong> <span class="col-sm-3">1<span style="padding-left:30px ;"> Application form</span></span></strong>
                            <strong><span class="col-sm-3" style="padding-left:80px ;">2<span style="padding-left:30px ;"> upload document</span></span></strong>
                            <strong><span class="col-sm-3" style="padding-left:80px ; ">3<span style="padding-left:30px ;"> payment method</span></span></strong>
                          </div>
                       
                              
                            <br>
                            <br>  
                            <h1><strong>Caste Certificate</strong></h1>
                            
                 
                        <div class="card">
                           <div class="card-body">
                              
                               
                                <div class="col-xs-12 col-sm-12 col-md-3">
                                     <label class="manadatory" for="Caste_Certificate">Caste Certificates</label>
                                     <select class="form-control" id="ddlCaste" name="Caste_Certificate_Value"><option value="" selected="selected" required>---Select---</option>
                                             <option value="Caste Migrant Certificate">Caste Migrant Certificate</option>
                                             <option value="Caste SC Certificate">Caste SC Certificate</option>
                                             <option value="Caste ST Certificate">Caste ST Certificate</option>
                                             <option value="Caste OBC Certificate">Caste OBC Certificate</option>
                                             <option value="Caste SBC Certificate">Caste SBC Certificate</option>
                                             <option value="Caste VJNT Certificate">Caste VJNT Certificate</option>
                                             <option value="Caste Buddhism Certificate">Caste Buddhism Certificate</option>
                                             <option value="Caste Certificate For GOI Posts">Caste Certificate For GOI Posts</option>
                                             <option value="Caste ESBC Certificate">Caste ESBC Certificate</option>
                                      </select>
                                     
                                     <div class="invalid-feedback" >please select caste</div>

                                 </div>

       
                           </div>
                       </div> 
                       
              <!--*****************************************************************************************************************-->
                                                             
                         <br>
                        <div class="card ">
                            <div class="card-header backround-color:#001b4d"><h4>Applicants Details</h4></div>
                          
                        </div>  
            <!--*****************************************************************************************************-->       
                       <div class="card">
                           <div class="card-body">
                               <div class="row ">
                                   <div class="form-group col-sm-2">
                                       <label for="salutation">Salutation</label>
                                       <select class="form-control" id="salutation" name="salutation" required>
                                           <option selected> <?php echo $row['salutation'];?></option>
                                           <option>--Select--</option>
                                           <option>Advocate</option>
                                           <option>Kumar</option>
                                           <option>Kumari</option>
                                           <option>Mr.</option>
                                           <option>Mrs</option>
                                            <option>Shri</option>
                                             <option>Shrimati</option>
                                              </select>   
                                       <div class="invalid-feedback" >please select caste</div>
                                   </div>
                                   
                                   <div class="form-group col-sm-5 ">
                                       <label >Full Name(English)</label>
                                       <input type="text" class="form-control" id="fullnameEnglish" name="fullnameEnglish" required value="<?php echo $row['fullnameEnglish']?>">
                                      <div class="invalid-feedback">
                                     Please Enter Valid name .
                                    </div>
                                   </div>
                                   
                                   <div class="form-group col-sm-5">
                                           <label for="nameMarathi">Full Name(Marathi)</label>
                                           <input type="text" id="fullnameMarathi" class="form-control" name="fullnameMarathi" required>
                                           <div class="invalid-feedback" >please select caste</div>
                                       </div>
                                       
                               </div>   
             
                  <!------------------------------------------------------------------------------>                                          
   
                                <div class="row">
                                     
                                    <div class="form-group col-sm-2">
                                        <label >Father's Salutation</label>
                                        <select class="form-control" id="fatherSalutation" name="fatherSalutation">
                                            <option>--Select--</option>                                          
                                           <option>Mr.</option>
                                            <option>Shri</option>
                                        </select>    
                                        
                                    </div> 
                                       
                                    <div class="form-group col-sm-5">
                                        <label >Father's Name(English)</label>
                                        <input type="text" class="form-control" id="fatherNameEnglish" name="fatherNameEnglish">
                                    </div>                                                                            
                                
                                    <div class="form-group col-sm-5">
                                        <label >Father's Name(Marathi)</label>
                                        <input type="text" class="form-control" id="fatherNameMarathi" name="fatherNameMarathi">
                                    </div> 
                                    
                                    
                                </div>
                  <!----------------------------------------------------------------------------->
                  
                                <div class="row">
                                   <div class="form-group col-sm-2">
                                           <label for="Adob">Date of Birth</label>
                                           <input type="date" id="dob" class="form-control" name="Adob">
                                    </div>
                                       
                                    <div class="form-group col-sm-1">
                                        <label for="Aage">Age</label>
                                        <input type="text" class="form-control" id="age" name="Aage">
                                    </div>
                                    
                                      <div class="form-group col-sm-2">
                                           <label for="mob">Mobile Number</label>
                                           <input type="tel" id="Amob" class="form-control" name="Amob">
                                   </div>
                                    
                                    <div class="form-group col-sm-2">
                                        <label for="gender">Gender</label>
                                        <select class="form-control" id="Agender" name="Agender">
                                            <option>--Select--</option>
                                            <option>Male</option>
                                            <option>Female</option>
                                            <option>Other</option>
                                        </select>
                                    </div>  
                                    
                                     <div class="form-group col-sm-5">
                                           <label for="Aemail">Email ID</label>
                                           <input type="email" id="Aemail" class="form-control" name="Aemail">
                                   </div>
                                       
                                </div>
                  
                  <!--------------------------------------------------------------------------------->
                  
                          
                            <div class="row">
                                   <div class="form-group col-sm-2">
                                        <label for="occupation">Occupation</label>
                                        <select class="form-control" id="Aoccupation" name="Aoccupation">
                                            
                                <option value="" selected="selected">---Select---</option>
<option value="Artist">Artist</option>
<option value="B.A">B.A</option>
<option value="B.E">B.E</option>
<option value="Bussiness">Bussiness</option>
<option value="Doctor">Doctor</option>
<option value="Engineer">Engineer</option>
<option value="Farm Wages">Farm Wages</option>
<option value="Farmer">Farmer</option>
<option value="Government Employee">Government Employee</option>
<option value="Hardware Professional">Hardware Professional</option>
<option value="Housewife">Housewife</option>
<option value="Industrialist">Industrialist</option>
<option value="Lawyer">Lawyer</option>
<option value="Nurse">Nurse</option>
<option value="Others">Others</option>
<option value="Private Service">Private Service</option>
<option value="Professor">Professor</option>
<option value="Software Professional">Software Professional</option>
<option value="Student">Student</option>
<option value="Teacher">Teacher</option>
<option value="Wages">Wages</option>
<option value="Worker">Worker</option>
<option value="Writer">Writer</option>
</select>
 <input class="form-control" id="ApplicantOccupation" name="BasicInformation.ApplicantOccupation" value="" type="hidden">
            </div>

                                              
                                    <div class="form-group col-sm-5">
                                        <label for="aadhar">Aadhar Number</label>
                                        <input type="text" class="form-control" id="Aadhar" name="Aadhar">
                                    </div>                  
                                
                                     <div class="form-group col-sm-5">
                                           <label for="applicantNationality">Applicant Nationality</label>
                                           <input type="email" id="AapplicantNationality" class="form-control" name="AapplicantNationality" >
                                   </div>
                                    
                                </div>
                           </div>
                       </div>
                  <!------------------------------------------------------------------------------------>
                           </div>
                       </div> 
            
              <!-- ***********************************************************************************************************-->        
                        <br>   
                         <div class="card">
                           <div class="card-body">
                               <div class="row ">
                                  
                                   <div class="form-group col-sm-3">
                                       <label for="address">Address</label>
                                       <input type="text" class="form-control" id="Aaddress" name="Aaddress">                                             
                                   </div>
                                   
                                   <div class="form-group col-sm-3">
                                       <label for="building">Building</label>
                                       <input type="text" class="form-control" id="Abuildiing" name="Abuilding">
                                   </div>
                                   
                                   <div class="form-group col-sm-3">
                                           <label for="section">Section</label>
                                           <input type="text" id="Asection" class="form-control" name="Asection">
                                       </div>
                                       
                                    <div class="form-group col-sm-3">
                                        <label for="street">Street</label>
                                        <input type="text" class="form-control" id="Astreet" name="Astreet">
                                    </div>   
                               </div>   
             
                  <!------------------------------------------------------------------------------>                                          
   
                                
                                <div class="row">
                                    <div class="form-group col-sm-3">
                                        <label for="landmark">Landmark</label>
                                        <input type="text" class="form-control" id="Alandmark" name="Alandmark">
                                    </div> 
                                    
                                     <div class="form-group col-sm-3">
                                        <label for="district">District</label>
                                        <select class="form-control" id="Adistrict" name="Adistrict">
                                               <option selected>--Your District--</option>
                      <option value="AHM">Ahmednagar</option>
                      <option value="AKO">Akola</option>
                      <option value="AMR">Amravati</option>
                      <option value="AUR">Aurangabad</option>
                      <option value="BEE">Beed</option>
                      <option value="BHA">Bhandara</option>
                      <option value="BUL">Buldana</option>
                      <option value="CHA">Chandrapur</option>
                      <option value="DHU">Dhule</option>
                      <option value="GAD">Gadchiroli</option>
                      <option value="GON">Gondiya</option>
                      <option value="HIN">Hingoli</option>
                      <option value="JAG">Jalgaon</option>
                      <option value="JAL">Jalna</option>
                      <option value="KOL">Kolhapur</option>
                      <option value="LAT">Latur</option>
                      <option value="MUM">Mumbai City</option>
                      <option value="MUS">Mumbai Suburban</option>
                      <option value="NAG">Nagpur</option>
                      <option value="NAN">Nanded</option>
                      <option value="NAD">Nandurbar</option>
                      <option value="NAS">Nashik</option>
                      <option value="OSM">Osmanabad</option>
                      <option value="PAL">Palghar</option>
                      <option value="PAR">Parbhani</option>
                      <option value="PUN">Pune</option>
                      <option value="RAI">Raigarh</option>
                      <option value="RAT">Ratnagiri</option>
                      <option value="SAN">Sangli</option>
                      <option value="SAT">Satara</option>
                      <option value="SIN">Sindhudurg</option>
                      <option value="SOL">Solapur</option>
                      <option value="THA">Thane</option>
                      <option value="WAR">Wardha</option>
                      <option value="WAS">Washim</option>
                      <option value="YAV">Yavatmal</option>
       	            </select>
                                            
                 </div> 
                                    
                                     <div class="form-group col-sm-3">
                                        <label for="taluka">Taluka</label>
                                        <select class="form-control" id="Ataluka" name="Ataluka">
                                            <option>--Select--</option>
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                        </select>                                           
                                    </div> 
                                       
                                    <div class="form-group col-sm-3">
                                        <label for="village">Village</label>
                                        <select class="form-control" id="Avillage" name="Avillage">
                                            <option>--Select--</option>
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                        </select>    
                                        
                                    </div>                
                                </div>
                  <!----------------------------------------------------------------------------->
                  
                                
                                <div class="row">
                                   <div class="form-group col-sm-3">
                                           <label for="pincode">Pincode</label>
                                           <input type="text" id="Apincode" name="Apincode"  class="form-control">
                                   </div>
                                </div>             
                  <!--------------------------------------------------------------------------------->
                  
                           </div>
                       </div> 
                        
                                              
            <!--*****************************************************************************************************-->                          
                       
                       <br>
                       <h3><strong>Relation Of Beneficiary With Applicant</strong></h3>
                       <div class="card">
                           <div class="card-body">
                               
                             <div class="row">
                                <div class="form-group col-sm-6">
                                    <label for="relation">Relation Of Beneficiary With Applicant</label>
                                    <select class="form-control" id="relben" name="relben">
                                        <option value="" selected="selected">---Select---</option>
                                        <option value="Brother">Brother</option>
                                        <option value="Daughter">Daughter</option>
                                        <option value="Father">Father</option>
                                        <option value="Grand Daughter">Grand Daughter</option>
                                        <option value="Grand Son">Grand Son</option>
                                        <option value="Husband">Husband</option>
                                        <option value="Mother">Mother</option>
                                        <option value="Nephew">Nephew</option>
                                        <option value="Niece">Niece</option>
                                        <option value="Self">Self</option>
                                        <option value="Sister">Sister</option>
                                        <option value="Son">Son</option>
                                        <option value="Wife">Wife</option>
                                        
                                    </select>
                                </div>
                             </div>
                               
                           </div>
                           <div class="form-group" id="returndata" name="returndata"> </div>
                           </fieldset>

                           
                       </div>
                       <div class="row">
                             
                           <input type="submit" class="form-control btn btn-primary col-md-2" id="addappinfo" name="addappinfo" value="SAVE">
                           <input type="submit"  style="display: none;" class="form-control btn btn-primary col-md-2" id="updateappinfo" name="updateappinfo" value="UPDATE">
                       <a href="BeneficiaryDetail.php" class="btn btn-primary">Next..</a>
            
                       </div>
                       
                       </div>
          
            </form>
            
            <script>
            $(document).ready(function(){
             $('#apform').on('click', '#addappinfo', function(event){  
             event.preventDefault();  
              // var form=$('form').get(0); 
               //console.log(form);
              $.ajax({  
                   url:"savep.php",  
                method:"POST", 
               // dataType:"JSON",
                //type: "POST",
                 //contentType: false,
                  //processData:false,
                   data:$('#apform').serialize(),
                   success:function(result){  
                   console.log(result);
                   $('#myfieldset').attr("disabled","disabled");
                   $('#addappinfo').hide();
                   $('#updateappinfo').show();
                   alert("Your Information Saved");  
  
                 },
                error:function(){
                    alert("Your Info Not Saved");
                  
                     },
  
   
   
     
   });  
  }  
 );
              $('#apform').on('click', '#updateappinfo', function(){  
                   $('#myfieldset').attr("disabled"," ");
                   $('#addappinfo').show();
                   $('#updateappinfo').hide();
            
      });
  }
      );
            
            </script>
        </div>
     <?php
                                    }                              
                                ?>
    </body></html>


