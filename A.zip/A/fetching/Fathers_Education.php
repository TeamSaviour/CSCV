<!DOCTYPE html>
<html>
<head>





	<title>Father's education and migration</title>

	 <link rel="stylesheet" type="text/css" href="bootstrap.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


	<style type="text/css">
		.form-group.required .control-label:before {
  content:"*";
  color:red;
}
  span{
     color: red;
  }

body{
	padding-top: 4.5rem;
	padding-bottom: 4.5rem;

}


header
{
	font-family: 'Lobster', cursive;
	text-align: center;
	font-size: 25px;
}

#info
{
	font-size: 18px;
	color: #555;
	text-align: center;
	margin-bottom: 25px;
}

a{
	color: #074E8C;
}
.bg-info{
	font-size: 20px;
}
#area{
	background: #ffe6e6;
	border-left: #ffeb3b;
}

.wrapper {
    text-align: center;
}

.button {
    position: absolute;
    top: 50%;
}

.alert {
  border-left: 6px solid #ffeb3b;
  }
.previous {
    background-color: #f1f1f1;
    color: black;
}
a {
    text-decoration: none;
    display: inline-block;
    padding: 8px 16px;
}

a:hover {
    background-color: #ddd;
    color: black;
}
.next {
    background-color: #4CAF50;
    color: white;
}
.save{
	 background-color: #4CAF50;
    color: white;

}
button:hover{
	background-color: #ddd;
    color: black;
}
button{
	text-decoration: none;
    display: inline-block;
    padding: 8px 16px;

}
.buttonholder{
	text-align: center;
}

	</style>


	<script>
	// Example starter JavaScript for disabling form submissions if there are invalid fields
	(function() {
	  'use strict';
	  window.addEventListener('load', function() {
	    // Fetch all the forms we want to apply custom Bootstrap validation styles to
	    var forms = document.getElementsByClassName('needs-validation');
	    // Loop over them and prevent submission
	    var validation = Array.prototype.filter.call(forms, function(form) {
	      form.addEventListener('submit', function(event) {
	        if (form.checkValidity() === false) {
	          event.preventDefault();
	          event.stopPropagation();
	        }
	        form.classList.add('was-validated');
	      }, false);
	    });
	  }, false);
	})();
	</script>


</head>
<body>

	<?php
							require_once 'connection.php';
							$sql="select * from fathersDmigration where username='akshay'";
						$result= mysqli_query($connection, $sql);
																while ($row=mysqli_fetch_array($result)){


							?>





<form class="needs-validation" action="father.php" method="post" novalidate>
	<div class="container-fluid col-md-8">
		 <div class="card col-md-12">
      <div class="form-group bg-info text-white card-header col-md-12">
        	    Father's Education Details
            </div>

            <div class="card col-md-12">
            <div class="form-group required ">
                    <label for="qualification" class="col-md-12 col-form-label control-label">Father's Qualification</label>
                    <input type="text" class="form-control col-md-6" name="qualification" id="qualification" value="<?php echo $row['fathersqualification'];?>" placeholder="Qualification" required>
										<div class="invalid-feedback">Enter The Qualification</div>
            </div>



        <table id="myTable" class=" table order-list">
    <thead>
        <tr>
            <td>Education Category</td>
            <td>Institute name</td>
            <td>Institute Address</td>
            <td>Year From</td>
            <td>Year to</td>

        </tr>
    </thead>
    <tbody>
        <tr>
            <td class="col-sm-4">
                <input type="text" name="feducation" class="form-control col-md-2" />
            </td>
            <td class="col-sm-4">
                <input type="text" name="fi_name"  class="form-control"/>
            </td>
            <td class="col-sm-3">
                <input type="text" name="fi_address"  class="form-control"/>
            </td>
            <td class="col-sm-3">
                <input type="text" name="ffrom"  class="form-control"/>
            </td>
            <td class="col-sm-3">
                <input type="text" name="fto"  class="form-control"/>
            </td>

            <td colspan="5">
                <input type="button" class="btn btn-lg btn-block " id="addrow" value="Add Row" />
            <td class="col-sm-2"><a class="deleteRow"></a></td>
            </td>
        </tr>
    </tbody>

</table>
<script type="text/javascript">

$(document).ready(function () {
    var counter = 0;

    $("#addrow").on("click", function () {
        var newRow = $("<tr>");
        var cols = "";

        cols += '<td><input type="text" class="form-control col-md-2" name="education' + counter + '"/></td>';
        cols += '<td><input type="text" class="form-control col-md-2" name="i_name' + counter + '"/></td>';
        cols += '<td><input type="text" class="form-control col-md-2" name="i_address' + counter + '"/></td>';
        cols += '<td><input type="text" class="form-control col-md-2" name="from' + counter + '"/></td>';
        cols += '<td><input type="text" class="form-control col-md-2" name="to' + counter + '"/></td>';

        cols += '<td><input type="button" class="ibtnDel btn btn-md btn-danger "  value="Delete"></td>';
        newRow.append(cols);
        $("table.order-list").append(newRow);
        counter++;
    });



    $("table.order-list").on("click", ".ibtnDel", function (event) {
        $(this).closest("tr").remove();
        counter -= 1
    });


});



function calculateRow(row) {
    var price = +row.find('input[name^="price"]').val();

}

function calculateGrandTotal() {
    var grandTotal = 0;
    $("table.order-list").find('input[name^="price"]').each(function () {
        grandTotal += +$(this).val();
    });
    $("#grandtotal").text(grandTotal.toFixed(2));
}


</script>



        <div class="form-group col-md-6 row" required>

        	<label class="col-md-3">Father's occupation</label>

          <!---  <label class="radio-inline col-md-3"><input type="radio" name="optradio">Service</label>
            <label class="radio-inline col-md-3"><input type="radio" name="optradio">Business</label>
            <label class="radio-inline col-md-3"><input type="radio" name="optradio">other</label>

					-->

					<select class="form-control custom-select" id="occupation" name="occupation" required>
   		                <option><?php echo $row['fathersoccupation'];?></option>
       	                <option>Service</option>
       	                <option>Business</option>
                        <option>Others</option>

       	            </select>



			  </div>


        <div class="form-group row" >
   		    <div class="col-md-6" required has>
   		        <label for="of_name" class="col-md-12 col-form-label control-label">Office Name</label>
   			        <input type="text" class="form-control" id="of_name" name="of_name" value="<?php echo $row['officename'];?>" placeholder="Office Name" required>
   		        <div class="invalid-feedback">Fill Office Name </div>
   		    </div>
   		    <div class="form-group col-md-6 required">
   			    <label for="designation" class="col-md-12 col-form-label">Designation</label>
 			        <input type="text" class="form-control" id="designation" name="designation" value="designation" placeholder="Designation" required>

   		    </div>
        </div>


        <div class="form-group required">
                    <label for="of_address" class="col-md-12 col-form-label control-label">Office Address</label>
                        <textarea class="form-control" rows="2" id="of_address"  name="of_address" value="" required><?php echo $row['officeaddress'];?></textarea>

        </div>


        <div class="form-group required">
                    <label for="of_number" class="col-md-6 col-form-label control-label">Office contact no</label>
                        <input type="text" class="form-control" id="of_number" name="of_number" plceholder="Office contact Number" value="<?php echo $row['officecontact'];?>" required>

        </div>



        <div class="form-group required">
                    <label for="tr_business" class="col-md-6 col-form-label control-label">Traditional Business
                        <input type="text" class="form-control" id="tr_business" name="tr_business" value="<?php echo $row['traditionalbusiness'];?>" plceholder="Office contact Number" required>
                    </label>
        </div>

    </div>
</p>




        <!-- Mention Migration Details -->

<div class="buttonholder">
      	<a href="Student_education_details.html" class="previous">&laquo; Previous</a>
       	<button type="submit" class="save" id="save">Save</button>
       <a href="Bloodrelationpreviousapplicationdetails.html" class="next" id="next">Next &raquo;</a>

       </div>
</div>

	</div>
</form>
<?php
															 }
															  ?>

</body>
</html>
