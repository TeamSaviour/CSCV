<!DOCTYPE html>
<html>
<head>
	<script>
	// Example starter JavaScript for disabling form submissions if there are invalid fields
	(function() {
	  'use strict';
	  window.addEventListener('load', function() {
	    // Fetch all the forms we want to apply custom Bootstrap validation styles to
	    var forms = document.getElementsByClassName('needs-validation');
	    // Loop over them and prevent submission
	    var validation = Array.prototype.filter.call(forms, function(form) {
	      form.addEventListener('submit', function(event) {
	        if (form.checkValidity() === false) {
	          event.preventDefault();
	          event.stopPropagation();
	        }
	        form.classList.add('was-validated');
	      }, false);
	    });
	  }, false);
	})();
	</script>



	<title>Education and native place details</title>
	 <link rel="stylesheet" type="text/css" href="bootstrap.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


	<style type="text/css">
		.form-group.required .control-label:before {
  content:"*";
  color:red;
}
  span{
     color: red;
  }

body{
	padding-top: 4.5rem;
	padding-bottom: 4.5rem;

}


header
{
	font-family: 'Lobster', cursive;
	text-align: center;
	font-size: 25px;
}

#info
{
	font-size: 18px;
	color: #555;
	text-align: center;
	margin-bottom: 25px;
}

a{
	color: #074E8C;
}
.bg-info{
	font-size: 20px;
}
#area{
	background: #ffe6e6;
	border-left: #ffeb3b;
}

.wrapper {
    text-align: center;
}

.button {
    position: absolute;
    top: 50%;
}

.alert {
  border-left: 6px solid #ffeb3b;
  }
.previous {
    background-color: #f1f1f1;
    color: black;
}
a {
    text-decoration: none;
    display: inline-block;
    padding: 8px 16px;
}

a:hover {
    background-color: #ddd;
    color: black;
}
.next {
    background-color: #4CAF50;
    color: white;
}
.save{
	 background-color: #4CAF50;
    color: white;

}
button:hover{
	background-color: #ddd;
    color: black;
}
button{
	text-decoration: none;
    display: inline-block;
    padding: 8px 16px;

}
.buttonholder{
	text-align: center;
}

	</style>
</head>
<body>

	<?php
							 require_once 'connection.php';
							 $sql="select * from stuappnativedetails where username='jv'";
						 $result= mysqli_query($connection, $sql);
																 while ($row=mysqli_fetch_array($result)){


							 ?>




<form class="needs-validation" novalidate action="St_edupdate.php" method="post">
	<div class="container-fluid col-md-8">
		 <div class="card col-md-12">

   <p class="bg-info text-white card-header col-md-12 ">Student Education Details</p>



		<div class="alert alert-warning col-md-12">
			Select District and Taluka where applicant's college is located
		</div>



   <div class="card col-md-12">
        <div class="form-group required row" >
   		    <div class="col-md-6">
   		        <label for="district" class="col-md-12 col-form-label control-label">District
   			   		<select class="form-control" name="district" id="district">
   		               <option selected value=""> <?php echo $row['district'];?></option>
                      <option value="AHM">Ahmednagar</option>
                      <option value="AKO">Akola</option>
                      <option value="AMR">Amravati</option>
                      <option value="AUR">Aurangabad</option>
                      <option value="BEE">Beed</option>
                      <option value="BHA">Bhandara</option>
                      <option value="BUL">Buldana</option>
                      <option value="CHA">Chandrapur</option>
                      <option value="DHU">Dhule</option>
                      <option value="GAD">Gadchiroli</option>
                      <option value="GON">Gondiya</option>
                      <option value="HIN">Hingoli</option>
                      <option value="JAG">Jalgaon</option>
                      <option value="JAL">Jalna</option>
                      <option value="KOL">Kolhapur</option>
                      <option value="LAT">Latur</option>
                      <option value="MUM">Mumbai City</option>
                      <option value="MUS">Mumbai Suburban</option>
                      <option value="NAG">Nagpur</option>
                      <option value="NAN">Nanded</option>
                      <option value="NAD">Nandurbar</option>
                      <option value="NAS">Nashik</option>
                      <option value="OSM">Osmanabad</option>
                      <option value="PAL">Palghar</option>
                      <option value="PAR">Parbhani</option>
                      <option value="PUN">Pune</option>
                      <option value="RAI">Raigarh</option>
                      <option value="RAT">Ratnagiri</option>
                      <option value="SAN">Sangli</option>
                      <option value="SAT">Satara</option>
                      <option value="SIN">Sindhudurg</option>
                      <option value="SOL">Solapur</option>
                      <option value="THA">Thane</option>
                      <option value="WAR">Wardha</option>
                      <option value="WAS">Washim</option>
                      <option value="YAV">Yavatmal</option>
       	            </select>
   		        </label>
							 <div class="invalid-feedback">please select the district</div>
   		    </div>



   		    <div class="form group required col-md-6">
   			    <label for="taluka" class="col-md-12 col-form-label control-label">Taluka
 					<select class="form-control" name="taluka" id="select">
   		                <option> <?php echo $row['taluka'];?></option>
       	                <option>Ahmednagar</option>
       	                <option>Akola</option>
                        <option>Amravati</option>
                        <option>Aurangabad</option>
       	            </select>
                </label>
								 <div class="invalid-feedback">please select the taluka</div>
   		    </div>
   	    </div>




        <div class="form-group required">
            <label for="select" class="col-md-12 col-form-label control-label">Institute/College Name
                <select class="form-control" name="institutename" id="select" required>
   		            <option> <?php echo $row['collegename'];?></option>
       	            <option>Ahmednagar</option>
       	            <option>Akola</option>
                    <option>Amravati</option>
                    <option>Aurangabad</option>
       	        </select>
            </label>
						 <div class="invalid-feedback">please select the institute</div>
        </div>


        <div class="form-group required">
            <label for="course" class="col-md-12 col-form-label control-label">Course Name
                <select class="form-control" id="course" name="course" required>
   		            <option> <?php echo $row['coursename'];?></option>
       	            <option>Ahmednagar</option>
       	            <option>Akola</option>
                    <option>Amravati</option>
                    <option>Aurangabad</option>
       	        </select>
            </label>
        </div>






        <div class="form-group required row" >
   		    <div class="col-md-6">
   		        <label for="year" class="col-md-12 col-form-label control-label">Year(YYYY)
   			        <input type="text" class="form-control" id="year" name="year" value=" <?php echo $row['year'];?>" placeholder="YYYY" required>
   		        </label>
   		    </div>
   		    <div class="form group col-md-6">
   			    <label for="telephone" class="col-md-12 col-form-label">Insitute/College Telephone No.
 			        <input type="text" class="form-control" name="institutephone" id="telephone" placeholder="Telephone No." value=" <?php echo $row['collegephono'];?>" >
                </label>
   		    </div>
        </div>


            <div class="form-group required">
                    <label for="reg_no" class="col-md-12 col-form-label control-label">Permanent Registration Number allocated to applicant
                        <input type="text" class="form-control col-md-6" id="reg_no" name="prn" value=" <?php echo $row['permanantregno'];?>" placeholder="Registration Number" required>
                    </label>
										 <div class="invalid-feedback">enter the permanant college Number </div>
            </div>



        <div class="form-group required row" >
   		    <div class="col-md-6">
   		        <label for="division" class="col-md-12 col-form-label control-label"> Applicant's Division
   			        <input type="text" class="form-control" name="division" id="division" value=" <?php echo $row['applicantdiv'];?>" placeholder="Division" required>
   		        </label>
							 <div class="invalid-feedback">Applicant division</div>
   		    </div>
   		    <div class="form group col-md-6">
   			    <label for="roll_no" class="col-md-12 col-form-label">Applicant's Roll No.
 			        <input type="text" class="form-control" id="roll_no" name="roll_no" value=" <?php echo $row['app_rollno'];?>" placeholder="Roll No." required>
                </label>
								 <div class="invalid-feedback">roll no.</div>
   		    </div>
        </div>


            <div class="form-group required">
                    <label for="col_add" class="col-md-12 col-form-label control-label">Institute/ College Address
                        <input type="text" class="form-control col-md-12" id="col_add" name="college_address" value=" <?php echo $row['college_address'];?>" placeholder="Institute/College Address" required>
                    </label>
            </div>


        </div>


        <!-- Applicant Education details -->

         <p class="bg-info text-white card-header col-md-12 ">Applicant Education Details</p>

            <div class="alert alert-warning col-sm-12 ">
			Please fill all the fields for Education type Primary and Secondary. To add new Education category click on "Add" button
            </div>

         <div class="card">

        <table id="myTable" class=" table order-list">
    <thead>
        <tr>
            <td>Education Category</td>
            <td>Institute name</td>
            <td>Institute Address</td>
            <td>Year From</td>
            <td>Year to</td>

        </tr>
    </thead>
    <tbody>
        <tr>
            <td class="col-sm-4">
                <input type="text" name="education" class="form-control col-md-2" />
            </td>
            <td class="col-sm-4">
                <input type="text" name="i_name"  class="form-control"/>
            </td>
            <td class="col-sm-3">
                <input type="text" name="i_address"  class="form-control"/>
            </td>
            <td class="col-sm-3">
                <input type="text" name="from"  class="form-control"/>
            </td>
            <td class="col-sm-3">
                <input type="text" name="to"  class="form-control"/>
            </td>

            <td colspan="5">
                <input type="submit" class="btn btn-lg btn-block " id="addrow" value="Add Row" />
            <td class="col-sm-2"><a class="deleteRow"></a></td>
            </td>
        </tr>
    </tbody>

</table>
</div>

<script type="text/javascript">

$(document).ready(function () {
    var counter = 0;

    $("#addrow").on("click", function () {
        var newRow = $("<tr>");
        var cols = "";

        cols += '<td><input type="text" class="form-control col-md-2" name="education' + counter + '"/></td>';
        cols += '<td><input type="text" class="form-control col-md-2" name="i_name' + counter + '"/></td>';
        cols += '<td><input type="text" class="form-control col-md-2" name="i_address' + counter + '"/></td>';
        cols += '<td><input type="text" class="form-control col-md-2" name="from' + counter + '"/></td>';
        cols += '<td><input type="text" class="form-control col-md-2" name="to' + counter + '"/></td>';

        cols += '<td><input type="button" class="ibtnDel btn btn-md btn-danger "  value="Delete"></td>';
        newRow.append(cols);
        $("table.order-list").append(newRow);
        counter++;
    });



    $("table.order-list").on("click", ".ibtnDel", function (event) {
        $(this).closest("tr").remove();
        counter -= 1
    });


});



function calculateRow(row) {
    var price = +row.find('input[name^="price"]').val();

}

function calculateGrandTotal() {
    var grandTotal = 0;
    $("table.order-list").find('input[name^="price"]').each(function () {
        grandTotal += +$(this).val();
    });
    $("#grandtotal").text(grandTotal.toFixed(2));
}


</script>



            <!-- Native place details -->



    <div class="buttonholder">
      	<a href="Birth_place_details.html" class="previous">&laquo; Previous</a>
       	<button type="submit" class="save" id="save">Save</button>
       <a href="Family and parents details.html" class="next" id="next">Next &raquo;</a>

       </div>
</div>
</form>

<?php
															 }
															  ?>
</body>
</html>
