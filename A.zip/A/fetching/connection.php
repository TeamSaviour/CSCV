<?php
$host="localhost";
$username="root";
$password="";
$database="akshay";

$connection=mysqli_connect($host,$username,$password,$database);

?>
