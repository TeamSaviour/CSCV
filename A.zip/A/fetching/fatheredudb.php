
<?php

require 'connection.php';

if(isset($_POST)){


$education = $_POST['feducation'];
$i_name =$_POST['fi_name'];
$i_address = $_POST['fi_address'];
$from = $_POST['ffrom'];
$to = $_POST['fto'];

$sql="UPDATE fathersD&migration
 SET

    `aeid`='{DEFAULT}',
    `educatiocategory`= '{$education}',
    `institute`= '{$i_name}',
    `instituteaddr`= '{$i_address}',
    'yearfrom`= '{$from}',
    `yearto`= '{$to}'

    WHERE
    username='akshay'
    ";

    $result= mysqli_query($connection, $sql);
    if($result){
        echo 'Success';

    }
     else {
         echo 'failed'. mysqli_error($connection);
    }
    }

 ?>
