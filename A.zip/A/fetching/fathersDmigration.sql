-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 24, 2018 at 01:25 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `akshay`
--

-- --------------------------------------------------------

--
-- Table structure for table `fathersDmigration`
--

CREATE TABLE `fathersDmigration` (
  `ffid` int(11) NOT NULL,
  `fathersqualification` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fathersoccupation` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `officename` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `designation` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `officeaddress` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `officecontact` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `traditionalbusiness` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fathersDmigration`
--

INSERT INTO `fathersDmigration` (`ffid`, `fathersqualification`, `fathersoccupation`, `officename`, `designation`, `officeaddress`, `officecontact`, `traditionalbusiness`, `username`) VALUES
(1, 'vjjvj', 'Business', 'nm', 'designation', 'mnb', 'jbk', 'ujvu', 'akshay');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
