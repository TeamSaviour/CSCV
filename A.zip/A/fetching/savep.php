<?php
require 'connection.php';
if(isset($_POST)){
$salutation=$_POST['salutation'];
$fullnameEnglish=$_POST['fullnameEnglish'];
$fullnameMarathi=$_POST['fullnameMarathi'];
$fatherSalutation=$_POST['fatherSalutation'];
$fathernameEnglish=$_POST['fatherNameEnglish'];
$fathernameMarathi=$_POST['fatherNameMarathi'];
$dob=$_POST['Adob'];
$age=$_POST['Aage'];
$Aemail=$_POST['Aemail'];
$Amob=$_POST['Amob'];
$Agender=$_POST['Agender'];
$Aadhar=$_POST['Aadhar'];
$Aoccupation=$_POST['Aoccupation'];
$ApplicantNationality=$_POST['AapplicantNationality'];
$address=$_POST['Aaddress'];
$building=$_POST['Abuilding'];
$section=$_POST['Asection'];
$street=$_POST['Astreet'];
$landmark=$_POST['Alandmark'];
$district=$_POST['Adistrict'];
$taluka=$_POST['Ataluka'];
$village=$_POST['Avillage'];
$pincode=$_POST['Apincode'];
$relben=$_POST['relben'];

/*$sql="insert into appdetails(`pid`, `salutation`, `fullnameEnglish`, `fullnameMarathi`, 
    `fatherSalutation`, `fathernameEnglish`, `fathernameMarathi`, `dob`, `age`, `amob`, 
    `Agender`, `aemail`, `aoocupation`, `aaadhar`, `anationality`, `address`, `building`, 
    `section`, `street`, `landmark`, `district`, `taluka`, `village`, `pincode`, `relben`, 
    `username`) values(
        DEFAULT,
        '$salutation',
         '$fullnameEnglish',
          ' $fullnameMarathi',
          '$fatherSalutation',
                '$fathernameEnglish',
                '$fathernameMarathi',
                '$dob',
                '$age',
                '$Amob',
                '$Agender',
                '$Aemail',
                '$Aoccupation',
                '$Aadhar',
                '$ApplicantNationality',
                '$address','$building','$section','$street','$landmark','$district','$taluka','$village','$pincode','$relben','anand'
                    
        )";
*/

    $sql="UPDATE appdetails
     SET
        
        `salutation`='{$salutation}',
        `fullnameEnglish`= '{$fullnameEnglish}',
        `fullnameMarathi`= '{$fullnameMarathi}',
        `fatherSalutation`= '{$fatherSalutation}',
        `fathernameEnglish`= '{$fathernameEnglish}',
        `fathernameMarathi`= '{$fathernameMarathi}',
        `dob`= '{$dob}',
        `age`= '{$age}',
        `amob`= '{$Amob}',
        `Agender`= '{$Agender}',
        `aemail`= '{$Aemail}',
        `aoocupation`= '{$Aoccupation}',
        `aaadhar`= '{$Aadhar}',
        `anationality`= '{$ApplicantNationality}',
        `address`= '{$address}',
        `building`= '{$building}',
        `section`= '{$section}',
        `street`= '{$street}',
        `landmark`= '{$landmark}',
        `district`= '{$district}',
        `taluka`= '{$taluka}',
        `village`= '{$village}',
        `pincode`= '{$pincode}' ,
        `relben`= '{$relben}'
        WHERE
        username='anand'
        ";  
$result= mysqli_query($connection, $sql);
if($result){
    echo 'Success';
    
}
 else {
     echo 'failed'. mysqli_error($connection);
}
    
    
}
?>


