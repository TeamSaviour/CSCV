<?php
$host="localhost";
$username="root";
$password="";
$database="Practice";

$connection=mysqli_connect($host,$username,$password,$database);

?>
