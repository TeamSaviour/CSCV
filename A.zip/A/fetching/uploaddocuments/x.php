<!DOCTYPE html>

<html>
<head>
<meta charset="utf-8"/>
<title>upload</title>
</head>
<body>
  <?php
  include 'connection.php';
  if(isset($_POST['btnupload'])) {
    $name = $_FILES['myfile']['name'];
    $type = $_FILES['myfile']['type'];
    $tmp_name = $_FILES['myfile']['tmp_name'];
    $error = $_FILES['myfile']['error'];

    //$data = file_get_contents($_FILES['myfile']['tmp_name']);

    $data = addslashes(file_get_contents($tmp_name));

    $sql="INSERT INTO myblob VALUES(DEFAULT,'$name','$type','$data')";
    mysqli_query($connection, $sql);
      echo "sucess";

  }


   ?>

   <form method="post" enctype="multipart/form-data">
     <input type="file" name="myfile"/>

     <button name="btnupload">Upload</button>


   </form>
   <br>
   <br>
   <p></p>
   <ol>

<?php

  $view ="SELECT * FROM myblob ";
  $outputview = mysqli_query($connection, $view);

  while ($row = mysqli_fetch_assoc($outputview)) {
    echo "<li><a target='_blank' href='view.php?id=".$row['id']."'>".$row['name']."</a></li>";
  }

 ?>



</body>

</html>
