<?php

     session_start();

     $_SESSION['id']="1";

    if(isset($_POST["addappinfo"])) {
        
        require "connection.php";
        
       $query = "UPDATE `benfdet` SET `salutation` = '".mysqli_real_escape_string($connection, $_POST['Bsalutation'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);

          $query = "UPDATE `benfdet` SET `nameeng` = '".mysqli_real_escape_string($connection, $_POST['BnameEnglish'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
            mysqli_query($connection, $query);

         $query = "UPDATE `benfdet` SET `namemar` = '".mysqli_real_escape_string($connection, $_POST['BnameMarathi'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);

          $query = "UPDATE `benfdet` SET `dob` = '".mysqli_real_escape_string($connection, $_POST['Bdob'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
          $query = "UPDATE `benfdet` SET `mobile` = '".mysqli_real_escape_string($connection, $_POST['Bmob'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
          $query = "UPDATE `benfdet` SET `gender` = '".mysqli_real_escape_string($connection, $_POST['Bgender'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
         $query = "UPDATE `benfdet` SET `email` = '".mysqli_real_escape_string($connection, $_POST['Bemail'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
          $query = "UPDATE `benfdet` SET `adhar` = '".mysqli_real_escape_string($connection, $_POST['Badhar'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
          $query = "UPDATE `benfdet` SET `nationality` = '".mysqli_real_escape_string($connection, $_POST['Bnationality'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
          $query = "UPDATE `benfdet` SET `postname` = '".mysqli_real_escape_string($connection, $_POST['AOpostOffic'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
         $query = "UPDATE `benfdet` SET `occupation` = '".mysqli_real_escape_string($connection, $_POST['AOherediataryOccupation'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
          $query = "UPDATE `benfdet` SET `peraddr` = '".mysqli_real_escape_string($connection, $_POST['BpermanantAddress'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
          $query = "UPDATE `benfdet` SET `addrl1` = '".mysqli_real_escape_string($connection, $_POST['corresAddress1'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
          $query = "UPDATE `benfdet` SET `addrl2` = '".mysqli_real_escape_string($connection, $_POST['corresAddress2'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
         $query = "UPDATE `benfdet` SET `country` = '".mysqli_real_escape_string($connection, $_POST['acountry'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
          $query = "UPDATE `benfdet` SET `state` = '".mysqli_real_escape_string($connection, $_POST['astate'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
          $query = "UPDATE `benfdet` SET `district` = '".mysqli_real_escape_string($connection, $_POST['adistrict'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
          $query = "UPDATE `benfdet` SET `taluka` = '".mysqli_real_escape_string($connection, $_POST['ataluka'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
         $query = "UPDATE `benfdet` SET `village` = '".mysqli_real_escape_string($connection, $_POST['avillage'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          mysqli_query($connection, $query);
          
          $query = "UPDATE `benfdet` SET `pincode` = '".mysqli_real_escape_string($connection, $_POST['a_pincode'])."' WHERE id = ".mysqli_real_escape_string($connection, $_SESSION['id'])." LIMIT 1";
          
          $result=mysqli_query($connection, $query);

         header("location:familydetails.php");
        
    }

?>
