<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Caste Certificate And Validity System</title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
	<link rel="stylesheet" href="assets/css/ready.css">
	<link rel="stylesheet" href="assets/css/demo.css">
	<link rel="stylesheet" href="https://unpkg.com/bootstrap-material-design@4.1.1/dist/css/bootstrap-material-design.min.css" integrity="sha384-wXznGJNEXNG1NFsbm0ugrLFMQPWswR3lds2VeinahP8N0zJw9VWSopbjv2x7WCvX" crossorigin="anonymous">
</head>
<body>
	<div class="wrapper">
		<div class="main-header">
			<div class="logo-header">
				
				<a href="index.html" class="logo">
				CCVS
				</a>
				<button class="navbar-toggler sidenav-toggler ml-auto bmd-btn-fab dropdown-toggle" type="button" data-toggle="collapse" data-target="collapse" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				
			</div>
			
			</div>
			<div class="sidebar">
				<div class="scrollbar-inner sidebar-wrapper">
			
					
					<ul class="nav">
						<li class="nav-item active">
							<a href="index.html">
								<i class="la la-dashboard"></i>
								<p>Home</p>
								<span class="badge badge-count"></span>
							</a>
						</li>
						<li class="nav-item">
							<a href="components.html">
								<i class="la la-table"></i>
								<p>Apply</p>
								<span class="badge badge-count"></span>
							</a>
						</li>
						<li class="nav-item">
							<a href="forms.html">
								<i class="la la-keyboard-o"></i>
								<p>Downloads</p>
								<span class="badge badge-count"></span>
							</a>
						</li>
						<li class="nav-item">
							<a href="tables.html">
								<i class="la la-th"></i>
								<p>Upload Documents</p>
								<span class="badge badge-count"></span>
							</a>
						</li>
						<li class="nav-item">
							<a href="notifications.html">
								<i class="la la-bell"></i>
								<p>Edit Profile</p>
								<span class="badge badge-success"></span>
							</a>
						</li>
						<li class="nav-item">
							<a href="typography.html">
								<i class="la la-font"></i>
								<p>Verify Certificate</p>
								<span class="badge badge-danger"></span>
							</a>
						</li>
						<li class="nav-item">
							<a href="icons.html">
								<i class="la la-fonticons"></i>
								<p>Logout</p>
							</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="main-panel">
				<div class="content">
					<div class="container">            
        <?php
        
            $host="localhost";
            $username="root";
            $password="";
            $database="as";
            
            $conn= mysqli_connect($host, $username, $password, $database);
            
            if(!$conn)
            {
                 die("failed ".mysqli_connect_error() );    
                
            }
            //echo "connected";
            
            //$sql="select * from appdetails NATURAL JOIN address NATURAL JOIN relationofbeneficiary NATURAL JOIN  beneficiarydetails ";
            //$sql="select * from appdetails where id='2'";
            $sql="select * from appdetails apd INNER JOIN address appAddr on apd.id=appAddr.id INNER JOIN relationofbeneficiary rob on appAddr.id=rob.id "
                    . "INNER JOIN  beneficiarydetails bd on rob.id=bd.id INNER JOIN beneficiaryfatherdetails bfd on bd.id=bfd.id "
                    . "INNER JOIN  bfaddressdetails bfaAddr on bfd.id=bfaAddr.id INNER JOIN  bcastecategorydetails bccd on bfaAddr.id=bccd.id "
                    . "INNER JOIN  beneficiaryotherdetails bod on bccd.id=bod.id INNER JOIN attachmenttobeattached atba on bod.id=atba.id  "
                    . "INNER JOIN  additionalinfo ai on atba.id=ai.id  INNER JOIN  otherdetails od on ai.id=od.id where apd.id=2";
            
            $result=mysqli_query($conn, $sql);
             
            if (mysqli_num_rows($result) > 0)
          {
    // output data of each row
             while($row = mysqli_fetch_assoc($result))
            
            {
       // echo  "".$row["fullnameEnglish"];
    

        
        ?>
        
        
        
        

        <div class="container col-12">
            <form method="post" action="#">
            <div class="card">
                <div class="card-body">
                
                    <h3 class="card-title text-danger">1.&nbsp; Applicants Details</h3>   
                              
               <div class="card">
                   <div class="card-body">
                <div class="row" style="margin-left:35px">
                    <label ><strong>Full Name :</strong></label>    
                    <div style="margin-left: 95px"><?php echo $row['fullnameEnglish'] ?></div>
                </div>
              
                <div class="row" style="margin-left:35px">
                    <label ><strong>Father's Name :</strong> </label>    
                    <div style="margin-left: 65px"><?php echo $row['fathernameEnglish']; ?></div>
                </div>
                
                <div class="row" style="margin-left:35px">
                    <label ><strong>Date Of Birth :</strong> </label>    
                    <div style="margin-left: 75px"><?php echo $row['dob']; ?></div>
                </div>
                
                <div class="row" style="margin-left:35px">
                    <label ><strong>Age :</strong> </label>    
                    <div style="margin-left: 140px"><?php echo $row['age']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Mobile Number :</strong> </label>    
                    <div style="margin-left: 55px"><?php echo $row['amob']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Gender :</strong> </label>    
                    <div style="margin-left: 115px"><?php echo $row['Agender']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Email ID :</strong> </label>    
                    <div style="margin-left: 110px"><?php echo $row['aemail']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Occupation :</strong></label>    
                    <div style="margin-left: 85px"><?php echo $row['aoccupation']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Aadhar Number :</strong> </label>    
                    <div style="margin-left: 55px"><?php echo $row['aaadhar']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Applicant Nationality :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['anationality']; ?></div>
                </div>
                
                               
   <!---------------------------------------------------------------------------------------------------------------------------------------->          
                   
   
                
                <div class="row col-sm-8" style="background-color:yellow;margin-left:20px;font-size: 20px"><strong> Address Details</strong> </div>   

                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Address :</strong></label>    
                    <div style="margin-left: 50px"><?php echo $row['Address']; ?></div>
                </div >
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Building :</strong></label>    
                    <div style="margin-left: 50px"><?php echo $row['Building']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Section :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['Section']; ?></div>
                </div>
                
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Street :</strong></label>    
                    <div style="margin-left: 65px"><?php echo $row['Street']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Landmark :</strong></label>    
                    <div style="margin-left: 35px"><?php echo $row['Landmark']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>District :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['District']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Taluka :</strong></label>    
                    <div style="margin-left: 60px"><?php echo $row['Taluka']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Village :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['Village']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Pincode :</strong></label>    
                    <div style="margin-left: 45px"><?php echo $row['Pincode']; ?></div>
                </div>
                
        <!---------------------------------------------------------------------------------------------------------------------------------------->          
            
      <hr>
                
                <div class="row col-sm-11" style="background-color: greenyellow;margin-left:5px;font-size: 20px"><strong>2. &nbsp;Relation Of Beneficiary With Applicant</strong></div>   
                
                   
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Relation Of Beneficiary With Applicant :</strong></label>    
                    <div style="margin-left: 25px"><?php echo $row['relationOFBeneficiary']; ?></div>
                </div>
                </div>
               </div> 
                
                                  
      <!---------------------------------------------------------------------------------------------------------------------------------------->          
                <hr>
                 
                 <div class="row col-sm-11" style="background-color: greenyellow;margin-left:5px;font-size: 20px"><strong>3. &nbsp;Beneficiary Details</strong></div>   
                
                
                <div class="row" style="margin-left:35px">
                    <label ><strong>Full Name :</strong></label>    
                    <div style="margin-left: 95px"><?php echo $row['fullnamEnglish']; ?></div>
                </div>
              
                
                <div class="row" style="margin-left:35px">
                    <label ><strong>Date Of Birth :</strong></label>    
                    <div style="margin-left: 75px"><?php echo $row['dob']; ?></div>
                </div>
                
              
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Mobile Number :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['mob']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Gender :</strong></label>    
                    <div style="margin-left: 115px"><?php echo $row['gender']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Email ID :</strong></label>    
                    <div style="margin-left: 110px"><?php echo $row['email']; ?></div>
                </div>
               
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Aadhar Number :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['adhar']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Applicant Nationality :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['applicantNationality']; ?></div>
                </div>
                
     <!---------------------------------------------------------------------------------------------------------------------------------------->          
     
                
                
                <div class="row col-sm-8" style="background-color: yellow;margin-left:20px;font-size: 20px"><strong>Other Details</strong></div>   
                
               
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Name of the Post :</strong></label>    
                    <div style="margin-left: 60px"><?php echo $row['nameOfThePost']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Herediatary Occupation :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['herediataryOccupation']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Permanant Address (Yes/No) </strong></label>    
                    <div style="margin-left: 50px"><?php echo $row['permanantAddr']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>If migrated from one state to another state?(Yes/No) :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['ifMigrated']; ?></div>
                </div>          
                
    <!---------------------------------------------------------------------------------------------------------------------------------------->          
                  <hr>
                 
                 <div class="row col-sm-11" style="background-color: greenyellow;margin-left:5px;font-size: 20px"><strong>3. &nbsp;Beneficiary Father Details</strong></div>   
                
                
                <div class="row" style="margin-left:35px">
                    <label ><strong>Full Name :</strong></label>    
                    <div style="margin-left: 105px"><?php echo $row['fullnameE']; ?></div>
                </div>
                
                <div class="row" style="margin-left:35px">
                    <label ><strong>Date Of Birth :</strong></label>    
                    <div style="margin-left: 85px"><?php echo $row['dob']; ?></div>
                </div>
               
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Mobile Number :</strong></label>    
                    <div style="margin-left: 65px"><?php echo $row['mob']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Gender :</strong></label>    
                    <div style="margin-left: 125px"><?php echo $row['gender']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Email ID :</strong></label>    
                    <div style="margin-left: 120px"><?php echo $row['email']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Occupation :</strong></label>    
                    <div style="margin-left: 95px"><?php echo $row['occupation']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Aadhar Number :</strong></label>    
                    <div style="margin-left: 65px"><?php echo $row['adhar']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Applicant Nationality :</strong></label>    
                    <div style="margin-left: 30px"><?php echo $row['applicantNationality']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Herediatary Occupation:</strong></label>    
                    <div style="margin-left: 15px"><?php echo $row['herediataryOccupation']; ?></div>
                </div>
                
    <!---------------------------------------------------------------------------------------------------------------------------------------->          
    
                 
                 <div class="row col-sm-8" style="background-color: yellow;margin-left:20px;font-size: 20px"><strong>Beneficiary Father Address Details</strong></div>   
                
                
                <div class="row" style="margin-left:35px">
                    <label ><strong>Address :</strong></label>    
                    <div style="margin-left: 50px"><?php echo $row['Address']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Building :</strong></label>    
                    <div style="margin-left: 50px"><?php echo $row['Building']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Section :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['Section']; ?></div>
                </div>
               
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Street :</strong></label>    
                    <div style="margin-left: 65px"><?php echo $row['Street']; ?></div>
                </div>
                   
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Landmark :</strong></label>    
                    <div style="margin-left: 35px"><?php echo $row['Landmark']; ?></div>
                </div>
                

                 <div class="row" style="margin-left:35px">
                     <label ><strong>District :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['District']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Taluka :</strong></label>    
                    <div style="margin-left: 60px"><?php echo $row['Taluka']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Village :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['Village']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Pincode :</strong></label>    
                    <div style="margin-left: 45px"><?php echo $row['Pincode']; ?></div>
                </div>
                
                
      <!---------------------------------------------------------------------------------------------------------------------------------------->          
    
       <hr>
                 
                 <div class="row col-sm-11" style="background-color: greenyellow;margin-left:5px;font-size: 20px"><strong>4. &nbsp;Beneficiary Caste/Category Details</strong></div>   
                
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Caste :</strong></label>    
                    <div style="margin-left: 85px"><?php echo $row['caste']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Category :</strong></label>    
                    <div style="margin-left: 60px"><?php echo $row['category']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Religion :</strong></label>    
                    <div style="margin-left:65px"><?php echo $row['religion']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Sub Caste :</strong></label>    
                    <div style="margin-left: 55px"><?php echo $row['subcaste']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Mother Tounge :</strong></label>    
                    <div style="margin-left: 15px"><?php echo $row['mother_tounge']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Dialect :</strong></label>    
                    <div style="margin-left: 80px"><?php echo $row['dialect']; ?></div>
                </div>
                
             
       <!---------------------------------------------------------------------------------------------------------------------------------------->          
     
       <hr>
                 
                 <div class="row col-sm-11" style="background-color: greenyellow;margin-left:5px;font-size: 20px"><strong>5. &nbsp;Beneficiary Other Details</strong></div>   
                
                
                  <div class="row" style="margin-left:35px">
                      <label ><strong>original Village/Town(Place)/tahsil/district of the person</strong></label>    
                 </div>
                
            
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>District :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['originaldistrict']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Taluka :</strong></label>    
                    <div style="margin-left: 25px"><?php echo $row['originaltaluka']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Village :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['originalvillage']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Name of the Village/Town,if a person is residing in the Village/Town other than his original Village /</strong></label>
                     <label><strong>Town (ordinary place of residence) :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['nameOfVillageORTown']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>District :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['Residingdistrict']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Taluka :</strong></label>    
                    <div style="margin-left: 25px"><?php echo $row['Residingtaluka']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Village :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['Residingvillage']; ?></div>
                </div>
                
                  <div class="row" style="margin-left:35px">
                      <label ><strong>Year of leaving the original Village :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['yearOfLeaving']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:20px">
                     <label class="col-sm-12" ><strong>Reason for leaving the original Village ( i.e Education,employement etc.) :</strong></label>    
                    <div style="margin-left: 0px" class="col-sm-12"><?php echo $row['reasonForLeaving']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:20px">
                     <label class="col-sm-12"><strong>Reason for residing in the present Village ( i.e Education,employement etc.) :</strong></label>    
                    <div style="margin-left: 0px" class="col-sm-12"><?php echo $row['reasonForResiding']; ?></div>
                </div>
             
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Place Of Birth :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['birthPlace']; ?></div>
                </div>
                
                
                 <div class="row" style="margin-left:20px">
                     <label class="col-sm-12"><strong>Name of the primary school and Full Address :</strong></label>    
                    <div style="margin-left: 0px" class="col-sm-12"><?php echo $row['nameOfPschool']; ?></div>
                </div>
                
                <div class="row" style="margin-left:20px">
                    <label class="col-sm-12"><strong>Name of the secondary school and Full Address :</strong></label>    
                    <div style="margin-left: 0px" class="col-sm-12"><?php echo $row['nameOfSscool']; ?></div>
                </div>
                
                
      <!---------------------------------------------------------------------------------------------------------------------------------------->          
                  
       <hr>
                 
                 <div class="row col-sm-11" style="background-color: greenyellow;margin-left:5px;font-size: 20px"><strong>6. &nbsp;Attachment to be Attached</strong></div>   
                
                
                 
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Evidence in support of this Scheduled Caste Claim :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['evidence']; ?></div>
                </div>
                
                
                 <div class="row" style="margin-left:35px">
                     <label><strong>Extract of the birth register in respect of application,his father or relatives:</strong></label>    
                    <div style="margin-left: 25px"><?php echo $row['eofbirthRegister']; ?></div>
                </div>
                
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Extract of the Primary School Admission Register of the applicant :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['eofprimaryShoolAdmission']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Primary School Leaving Certificate of the applicant or his father :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['pschoolLeaving']; ?></div>
                </div>
                
                 <div class='row' style="margin-left:35px">
                     <label ><strong>Documentary evidence in regard to the Schedule Caste and ordinary place of residence prior to the </strong></label>
                     <label><strong>date of notification of such :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['documentaryEvidence']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label><strong>An extract of service record a (book) mentioning Scheduled Caste of the applicant's father or relatives </strong></label>
                     <label><strong> who are in Government or any other services if any :</strong></label>    
                     <div style="margin-left: 20px" ><?php echo $row['eofServiceRecords']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>True copy of Validity Certificate,if any of the other father or relatives which issued by the Scrutiny</strong></label>
                     <label><strong>Committee :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['trueCopyOfValidity']; ?></div>
                </div>
                
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Copy of Revenue record or village panchayat record,if any :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['copyOfRevenueRecord']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Other relevant documentary evidence,if any :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['otherRelevantDocuments']; ?></div>
                </div>

                
      
   <!---------------------------------------------------------------------------------------------------------------------------------------->          

       <hr>
                 
                 <div class="row col-sm-11" style="background-color: greenyellow;margin-left:5px;font-size: 20px"><strong>7. &nbsp;Additional Information</strong></div>   
                
                
                  <div class="row" style="margin-left:35px">
                      <label ><strong>Name of five villages where applicant's relatives reside :</strong></label>    
                    <div style="margin-left: -15px" class="row col-sm-12"><?php echo $row['nameOfVillages']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>GodNames  Scheduled Caste :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['godNamesSC']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label class="row col-sm-11"><strong>In case of a person converted to another religion,the names of the gods and goddesses worshiped by him prior to conversion :</strong></label>    
                    <div style="margin-left: -15px" class="col-sm-12"><?php echo $row['personConvertedToAnotherReligion']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>The applicant's father's/ grandfather's original village/town, tahsil and district :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['aFathersOriginalVillage']; ?></div>
                </div>
      
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>The evidence of the applicants original village/town, if any. :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['eOfOriginalVillages']; ?></div>
                </div>
                
                
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Whether the father or relatives obtained the Scheduled Caste :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['fatherOrRelativesObtainedSc']; ?></div>
                </div>
                
                
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>The Affidavit to be attached here with Form-2 and Form-3 :</strong></label>    
                    <div style="margin-left: 20px"><?php echo $row['affidavitToBeAttached']; ?></div>
                </div>
                
                
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Whether the applicant has applied to the Competent Authority in Maharastra State or Competent</strong></label>
                     <label><strong> Authority of other State previously for issuance of Scheduled Caste :</strong></label>    
                     <div style="margin-left: 20px"><?php echo $row['aAppliedToCompetentAuthority']; ?></div>
                </div>
                
                <div class="row" style="margin-left:35px">
                    <label ><strong>Whether a Validity Certificate is granted to the father or any relatives of the applicant by the Scrutiny</strong></label>
                    <label><strong>Committee :</strong></label>
                    <div style="margin-left: 20px" ><?php echo $row['validityIsGranted']; ?></div> 
                                    
                </div>
                
     <!---------------------------------------------------------------------------------------------------------------------------------------->          
              
     
                 
                 <div class="row col-sm-8" style="background-color: yellow;margin-left:20px;font-size: 20px"><strong>Other Details</strong></div>   
                
                
                 <div class="row" style="margin-left:20px">
                     <label class="col-sm-12"><strong>Reason :</strong></label>    
                    <div style="margin-left: 15px"  ><?php echo $row['reason']; ?></div>
                </div>
                
                 <div class="row" style="margin-left:35px">
                     <label ><strong>Do you need Affidavit ?</strong> </label>    
                    <div style="margin-left: 20px"><?php echo $row['doYouNeedAffidavit']; ?></div>
                </div>
               </div>
               </div></div>
                
                <div class="row">
                 <a href="casteandbirth.php" class="btn btn-primary btn-raised col-1">EDIT</a> &nbsp;  
                           <input type="submit" class="form-control btn-success btn-raised col-md-2" id="addappinfo" name="addappinfo" value="SUBMIT">
                           <input type="submit"  style="display: none;" class="form-control bg-primary col-md-2" id="updateappinfo" name="updateappinfo" value="UPDATE">
                           
            
                       </div>
                
                
                
             
                
                </div>
            </div>
            </form>
        </div>
  
            <?php
                            }
                   }
                   else 
                   {
                       echo "0 results";
                   }
                   
                   
                   
             ?>
   
                
        
    
        </div>
   
      	

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://unpkg.com/popper.js@1.12.6/dist/umd/popper.js" integrity="sha384-fA23ZRQ3G/J53mElWqVJEGJzU0sTs+SvzG8fXVWP+kJQ1lwFAOkcUOysnlKJC33U" crossorigin="anonymous"></script>
<script src="https://unpkg.com/bootstrap-material-design@4.1.1/dist/js/bootstrap-material-design.js" integrity="sha384-CauSuKpEqAFajSpkdjv3z9t8E7RlpJ1UP0lKM/+NdtSarroVKu069AlsRPKkFBz9" crossorigin="anonymous"></script>
<script>$(document).ready(function() { $('body').bootstrapMaterialDesign(); });</script>
<script src="assets/js/core/jquery.3.2.1.min.js"></script>
<script src="assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<script src="assets/js/core/popper.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>

<script src="assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>
<script src="assets/js/plugin/bootstrap-toggle/bootstrap-toggle.min.js"></script>
<script src="assets/js/plugin/jquery-mapael/jquery.mapael.min.js"></script>
<script src="assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
<script src="assets/js/ready.min.js"></script>
<script src="assets/js/demo.js"></script>
</body>
</html>