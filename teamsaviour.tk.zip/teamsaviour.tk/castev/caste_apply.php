
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Caste Certificate And Validity System</title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
	<link rel="stylesheet" href="../assets/css/ready.css">
	<link rel="stylesheet" href="../assets/css/demo.css">
        <style>
         
		.form-group.required .control-label:before {
  content:"*";
  color:red;
}
  span{
     color: red;
  }
 
            </style>
        <link rel="stylesheet" href="https://unpkg.com/bootstrap-material-design@4.1.1/dist/css/bootstrap-material-design.min.css" integrity="sha384-wXznGJNEXNG1NFsbm0ugrLFMQPWswR3lds2VeinahP8N0zJw9VWSopbjv2x7WCvX" crossorigin="anonymous">
</head>
<body>
	<div class="wrapper">
		<div class="main-header">
			<div class="logo-header">
				
				<a href="index.html" class="logo">
				CCVS
				</a>
				<button class="navbar-toggler sidenav-toggler ml-auto bmd-btn-fab dropdown-toggle" type="button" data-toggle="collapse" data-target="collapse" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				
			</div>
			
			</div>
			<div class="sidebar">
				<div class="scrollbar-inner sidebar-wrapper">
			
					
					<ul class="nav">
            <li class="nav-item active">
              <a href="#">
                <i class="la la-home"></i>
                <p>Home</p>
                <span class="badge badge-count"></span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#">
                <i class="la la-edit"></i>
                <p>Apply</p>
                <span class="badge badge-count"></span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#">
                <i class="la la-download"></i>
                <p>Downloads</p>
                <span class="badge badge-count"></span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#">
                <i class="la la-upload"></i>
                <p>Upload Documents</p>
                <span class="badge badge-count"></span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#">
                <i class="la la-user"></i>
                <p>Edit Profile</p>
                <span class="badge badge-success"></span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#">
                <i class="la la-files-o"></i>
                <p>Verify Certificate</p>
                <span class="badge badge-danger"></span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#">
                <i class="la la-sign-out"></i>
                <p>Logout</p>
              </a>
            </li>
          </ul>
				</div>
			</div>
			<div class="main-panel">
				<div class="content">
                                    <div class="container">
                                        <div class="car">
                                    <?php
							 require_once '../connection.php';
							 $sql="select * from studentdetails where username='jv'";
						 $result= mysqli_query($connection, $sql);
																 while ($row=mysqli_fetch_array($result)){


							 ?>




<form class="needs-validation" novalidate action="St_edupdate.php" method="post">
	

   <p class="bg-info text-white card-header col-md-12 ">Student Education Details</p>



		<div class="alert alert-warning col-md-12">
			Select District and Taluka where applicant's college is located
		</div>



   <div class="card col-md-12">
        <div class="form-group required row" >
   		    <div class="col-md-6">
   		        <label for="district" class="col-md-12 col-form-label control-label">District
   			   		<select class="form-control" name="district" id="district">
   		               <option selected value=""> <?php echo $row['district'];?></option>
                      <option value="AHM">Ahmednagar</option>
                      <option value="AKO">Akola</option>
                      <option value="AMR">Amravati</option>
                      <option value="AUR">Aurangabad</option>
                      <option value="BEE">Beed</option>
                      <option value="BHA">Bhandara</option>
                      <option value="BUL">Buldana</option>
                      <option value="CHA">Chandrapur</option>
                      <option value="DHU">Dhule</option>
                      <option value="GAD">Gadchiroli</option>
                      <option value="GON">Gondiya</option>
                      <option value="HIN">Hingoli</option>
                      <option value="JAG">Jalgaon</option>
                      <option value="JAL">Jalna</option>
                      <option value="KOL">Kolhapur</option>
                      <option value="LAT">Latur</option>
                      <option value="MUM">Mumbai City</option>
                      <option value="MUS">Mumbai Suburban</option>
                      <option value="NAG">Nagpur</option>
                      <option value="NAN">Nanded</option>
                      <option value="NAD">Nandurbar</option>
                      <option value="NAS">Nashik</option>
                      <option value="OSM">Osmanabad</option>
                      <option value="PAL">Palghar</option>
                      <option value="PAR">Parbhani</option>
                      <option value="PUN">Pune</option>
                      <option value="RAI">Raigarh</option>
                      <option value="RAT">Ratnagiri</option>
                      <option value="SAN">Sangli</option>
                      <option value="SAT">Satara</option>
                      <option value="SIN">Sindhudurg</option>
                      <option value="SOL">Solapur</option>
                      <option value="THA">Thane</option>
                      <option value="WAR">Wardha</option>
                      <option value="WAS">Washim</option>
                      <option value="YAV">Yavatmal</option>
       	            </select>
   		        </label>
							 <div class="invalid-feedback">please select the district</div>
   		    </div>



   		    <div class="form group required col-md-6">
   			    <label for="taluka" class="col-md-12 col-form-label control-label">Taluka
 					<select class="form-control" name="taluka" id="select">
   		                <option> <?php echo $row['taluka'];?></option>
       	                <option>Ahmednagar</option>
       	                <option>Akola</option>
                        <option>Amravati</option>
                        <option>Aurangabad</option>
       	            </select>
                </label>
								 <div class="invalid-feedback">please select the taluka</div>
   		    </div>
   	    </div>




        <div class="form-group required">
            <label for="select" class="col-md-12 col-form-label control-label">Institute/College Name
                <select class="form-control" name="institutename" id="select" required>
   		            <option> <?php echo $row['collegename'];?></option>
       	            <option>Ahmednagar</option>
       	            <option>Akola</option>
                    <option>Amravati</option>
                    <option>Aurangabad</option>
       	        </select>
            </label>
						 <div class="invalid-feedback">please select the institute</div>
        </div>


        <div class="form-group required">
            <label for="course" class="col-md-12 col-form-label control-label">Course Name
                <select class="form-control" id="course" name="course" required>
   		            <option> <?php echo $row['coursename'];?></option>
       	            <option>Ahmednagar</option>
       	            <option>Akola</option>
                    <option>Amravati</option>
                    <option>Aurangabad</option>
       	        </select>
            </label>
        </div>






        <div class="form-group required row" >
   		    <div class="col-md-6">
   		        <label for="year" class="col-md-12 col-form-label control-label">Year(YYYY)
   			        <input type="text" class="form-control" id="year" name="year" value=" <?php echo $row['year'];?>" placeholder="YYYY" required>
   		        </label>
   		    </div>
   		    <div class="form group col-md-6">
   			    <label for="telephone" class="col-md-12 col-form-label">Insitute/College Telephone No.
 			        <input type="text" class="form-control" name="institutephone" id="telephone" placeholder="Telephone No." value=" <?php echo $row['collegephono'];?>" >
                </label>
   		    </div>
        </div>


            <div class="form-group required">
                    <label for="reg_no" class="col-md-12 col-form-label control-label">Permanent Registration Number allocated to applicant
                        <input type="text" class="form-control col-md-6" id="reg_no" name="prn" value=" <?php echo $row['permanantregno'];?>" placeholder="Registration Number" required>
                    </label>
										 <div class="invalid-feedback">enter the permanant college Number </div>
            </div>



        <div class="form-group required row" >
   		    <div class="col-md-6">
   		        <label for="division" class="col-md-12 col-form-label control-label"> Applicant's Division
   			        <input type="text" class="form-control" name="division" id="division" value=" <?php echo $row['applicantdiv'];?>" placeholder="Division" required>
   		        </label>
							 <div class="invalid-feedback">Applicant division</div>
   		    </div>
   		    <div class="form group col-md-6">
   			    <label for="roll_no" class="col-md-12 col-form-label">Applicant's Roll No.
 			        <input type="text" class="form-control" id="roll_no" name="roll_no" value=" <?php echo $row['app_rollno'];?>" placeholder="Roll No." required>
                </label>
								 <div class="invalid-feedback">roll no.</div>
   		    </div>
        </div>


            <div class="form-group required">
                    <label for="col_add" class="col-md-12 col-form-label control-label">Institute/ College Address
                        <input type="text" class="form-control col-md-12" id="col_add" name="college_address" value=" <?php echo $row['college_address'];?>" placeholder="Institute/College Address" required>
                    </label>
            </div>


        </div>

</form>
        <!-- Applicant Education details -->

         <p class="bg-info text-white card-header col-md-12 ">Applicant Education Details</p>

            <div class="alert alert-warning col-sm-12 ">
			Please fill all the fields for Education type Primary and Secondary. To add new Education category click on "Add" button
            </div>

         <div class="card">
              
                         <div class="row" name="">
                <div class="form-group col-md-4">
                    
                    <label>Education Category</label>
                    <select class="custom-select" id="aeducat" name="aeducat">
                        <option>Primary</option>
                        <option>Secondary</option>
                        <option>College</option>
                    </select>
                </div>
                             <div class=" form-group col-md-4" ><label>Course Name</label>
                          <input type="textarea" placeholder="Enter Course" name="aecname" id="aecname" class="form-control"> </div>
                <div class="form-group col-md-4"> <label>Institute name</label>
                  <input type="textarea" placeholder="Enter Institute Name" name="aeduiname" id="aeduiname" class="form-control"> </div>
                <div class=" form-group col-md-4"> <label>Institute Address</label>
                  <input type="textarea" placeholder="Enter Institute Address..." name="aeduiaddress" id="aeduiaddress" class="form-control"> </div>
                <div class=" form-group col-md-4"> <label>Year From</label>
                  <input type="textarea" placeholder="Enter here.." name="aeduyfrom" id="aeduyfrom" class="form-control"> </div>
                <div class=" form-group col-md-3"> <label>Year to</label>
                  <input type="textarea" placeholder="Enter here.." name="aeduyto" id="aeduyto" class="form-control"> </div>
              </div>
            
             <button  class="btn btn-default btn-primary col-md-2" id="eduadd" name="eduadd" onclick=add();>Add</button>
                 <button  style="display: none;" class="btn btn-default btn-primary" id="eduupdate" name="eduupdate">Update</button>

                      
               
             
             
<div class="row">
			  <div id="education_table">
                  <table class="table table-bordered">
                      <tr>
			<th>Sr.No</th>
                          <th width="10%">Education Category</th>
                          <th width="10%">Course Name</th>
                          <th width="20%">Institute name</th>
                          <th width="20%">Institute Address</th>
                           <th width="10%">Year From</th>
                           <th width="10%">Year to</th>
                          <th >Action</th>
                      </tr>
            <?php
			$sno = 1;
    $query= "select * from education ORDER BY edu_id DESC";
     $result = mysqli_query($database, $query);
      while($row = mysqli_fetch_array($result))
      {
        ?>
        <tr>
			<td><?php echo $sno++; ?></td>
            <td><?php echo $row['year']?></td>
            <td><?php echo $row['course']?></td>
            <td><?php echo $row['board']?></td>
            <td><?php echo $row['mark']?></td>
            <td><?php echo $row['division']?></td>
            <td nowrap><button type="submit" class="btn btn-primary btn-edit" id="<?php echo $row['edu_id']; ?>" ><i class="fa fa-edit"></i></button>
			<button type="submit" class="btn btn-primary btn-remove" id="<?php echo $row['edu_id']; ?>"><i class="fa fa-remove"></i></button>

                </td>
                      </tr>
                      <?php
      }

                      ?>
                  </table>
				  </div>
              </div></div>
			  
			

<script>
$(document).ready(function(){
 $('#insert_form').on('click', '#eduadd', function(event){  
  event.preventDefault();  
  if($('#year').val() == "")  
  {  
   alert("Year is required");  
  }  
  else if($('#course').val() == '')  
  {  
   alert("Course is required");  
  }  
  else if($('#board').val() == '')
  {  
   alert("Board is required");  
  }else if($('#mark').val() == '')
  {  
   alert("Mark is required");  
  }else if($('#division').val() == '')
  {  
   alert("Division is required");  
  }
   
  else  
  {  
   $.ajax({  
    url:"eduinsert.php",  
    method:"POST",  
    data:$('#insert_form').serialize(),  
    beforeSend:function(){  
     $('#insert').val("Inserting");  
    },  
    success:function(data){  
     $('#insert_form')[0].reset();  
     //$('#add_data_Modal').modal('hide');  
     $('#education_table').html(data);  
    }  
   });  
  }  
 });
 

 var tbl_id;
$(document).on('click', '.btn-edit', function(ev){
			ev.preventDefault();
			var btn_button = $(this);
			btn_button.html(' <i class="fa fa fa-spinner fa-spin"></i> ');
			tbl_id = $(this).attr("id");
			$('.btn-reset').trigger('click');
			$.ajax({
			  cache: false,
			  url: 'eduselect.php', // url where to submit the request
			  type : "POST", // type of action POST || GET
			  dataType : 'json', // data type
			  data : { cmd: "get_details", tbl_id: tbl_id }, // post data || get data
			  success : function(result) {
				btn_button.html(' <i class="fa fa fa-pencil-square-o"></i> ');
				console.log(result);
				$("#year").val(result['year']);
				$("#course").val(result['course']);
				$("#board").val(result['board']);
				$("#mark").val(result['mark']);
				$("#division").val(result['division']).change();
				$('#eduadd').hide();
				$('#eduupdate').show();
			  },
			  error: function(xhr, resp, text) {
				console.log(xhr, resp, text);
			  }
			});
		});
		
 $('#insert_form').on('click', '#eduupdate', function(event){  
  event.preventDefault();  
  if($('#year').val() == "")  
  {  
   alert("Year is required");  
  }  
  else if($('#course').val() == '')  
  {  
   alert("Course is required");  
  }  
  else if($('#board').val() == '')
  {  
   alert("Board is required");  
  }else if($('#mark').val() == '')
  {  
   alert("Mark is required");  
  }else if($('#division').val() == '')
  {  
   alert("Division is required");  
  }
   
  else  
  {  //var ed_id=$(this).attr("id");
	 var year=$('#year').val();
	 var course=$('#course').val();
	 var board=$('#board').val();
	 var mark=$('#mark').val();
	 var division=$('#division').val();
	 
   $.ajax({  
    url:"eduupdate.php",  
    method:"POST",  
    data:{
		'ed_id':tbl_id,
		'year':year,
		'course':course,
		'board':board,
		'mark':mark,
		'division':division,
	},  
  
    success:function(data){  
     $('#insert_form')[0].reset();  
     //$('#add_data_Modal').modal('hide');  
     $('#education_table').html(data);  
	 $('#eduadd').show();
	 $('#eduupdate').hide();
    }  
   });  
  }  
 });
 $(document).on('click', '.btn-remove', function(e){
	 var id = $(this).attr("id");
  	$clicked_btn = $(this);
  	$.ajax({
  	  url: 'edudelete.php',
  	  type: 'POST',
  	  data: {
    	'delete': 1,
    	'id': id,
      },
      success: function(data){
        // remove the deleted comment
		$('#education_table').html(data);
        $clicked_btn.parent().remove();
        
      }
  	});
  });
		
});  	
</script>		
             
             
        <table id="myTable" class=" table order-list">
    <thead>
        <tr>
            <td>Education Category</td>
            <td>Institute name</td>
            <td>Institute Address</td>
            <td>Year From</td>
            <td>Year to</td>

        </tr>
    </thead>
    <tbody>
        <tr>
            <td class="col-sm-4">
                <input type="text" name="education" class="form-control col-md-2" />
            </td>
            <td class="col-sm-4">
                <input type="text" name="i_name"  class="form-control"/>
            </td>
            <td class="col-sm-3">
                <input type="text" name="i_address"  class="form-control"/>
            </td>
            <td class="col-sm-3">
                <input type="text" name="from"  class="form-control"/>
            </td>
            <td class="col-sm-3">
                <input type="text" name="to"  class="form-control"/>
            </td>

            <td colspan="5">
                <input type="submit" class="btn btn-lg btn-block " id="addrow" value="Add Row" />
            <td class="col-sm-2"><a class="deleteRow"></a></td>
            </td>
        </tr>
    </tbody>

</table>
</div>

<script type="text/javascript">


</script>



            <!-- Native place details -->



    <div class="buttonholder">
      	<a href="Birth_place_details.html" class="previous">&laquo; Previous</a>
       	<button type="submit" class="save" id="save">Save</button>
       <a href="Family and parents details.html" class="next" id="next">Next &raquo;</a>

       </div>
</div>
</form>

<?php
}
	?>
						</div>
					</div>
				</div>
				
			
	


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://unpkg.com/popper.js@1.12.6/dist/umd/popper.js" integrity="sha384-fA23ZRQ3G/J53mElWqVJEGJzU0sTs+SvzG8fXVWP+kJQ1lwFAOkcUOysnlKJC33U" crossorigin="anonymous"></script>
<script src="https://unpkg.com/bootstrap-material-design@4.1.1/dist/js/bootstrap-material-design.js" integrity="sha384-CauSuKpEqAFajSpkdjv3z9t8E7RlpJ1UP0lKM/+NdtSarroVKu069AlsRPKkFBz9" crossorigin="anonymous"></script>
<script src="../assets/js/core/jquery.3.2.1.min.js"></script>
<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>

<script src="../assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>
<script src="../assets/js/plugin/bootstrap-toggle/bootstrap-toggle.min.js"></script>
<script src="../assets/js/plugin/jquery-mapael/jquery.mapael.min.js"></script>
<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
<script src="../assets/js/ready.min.js"></script>
<script src="../assets/js/demo.js"></script>
</body>
</html>