<?php
$host="localhost";
$username="root";
$password="";
$database="ccvs";
$connection=mysqli_connect($host,$username,$password,$database);
?>