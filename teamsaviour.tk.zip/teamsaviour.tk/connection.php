<?php
$host="fdb18.awardspace.net";
$username="2668776_ccvs";
$password="sih2018@";
$database="2668776_ccvs";
$connection=mysqli_connect($host,$username,$password,$database);
?>