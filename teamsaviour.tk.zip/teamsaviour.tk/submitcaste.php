<?php
	session_start();
	require 'connection.php';
	echo "Hii";
	$username=$_SESSION['username'];
	echo $username;
	
		 $sql="select * from appdetails apd INNER JOIN familydetails fd on apd.username=fd.username "
                    . "INNER JOIN  appcaste ac on fd.username=ac.username where apd.username='$username'";
            
            $result=mysqli_query($connection, $sql);
             
           
             while($row = mysqli_fetch_assoc($result))
            
            {

       // echo  "".$row["fullnameEnglish"];
      
			$fname=$row['fullnameEnglish'];	
			echo $row['fullnameEnglish'];;
			$appcaste=$row['caste'];
			$acastecat=$row['accaste'];
			$acrelegion=$row['acrelegion'];


}
			$sql="insert into casteverifier1 values(DEFAULT,111,'$fname','$appcaste','$acastecat','111','submitted','111','$username')";
			$result=mysqli_query($connection,$sql);
			if($result){
				echo "Your Form Submitted";
			}
			$sql1="update appdetails set `status`='submitted' where username='$username'";
			$result1=mysqli_query($connection,$sql1);
			if($result1){
				echo "Your Form Submitted";
			}



?>